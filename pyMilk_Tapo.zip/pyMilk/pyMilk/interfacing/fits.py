'''
    Just a shorthand, really
'''
from .fits_lib import *
