import os
import re
import sys
import platform
import subprocess
from distutils.version import LooseVersion

from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext


class CMakeExtension(Extension):
    def __init__(self, name, package, sourcedir=''):
        super().__init__(name, sources=[])
        self.sourcedir = os.path.abspath(sourcedir)
        self.package = package


class CMakeBuildExt(build_ext):
    def run(self):
        self.inplace = True
        try:
            import pybind11
            if pybind11.version_info < (2, 11):
                raise ModuleNotFoundError("pybind11 version must be >= 2.11")
            out = subprocess.check_output(['cmake', '--version'])
        except Exception:
            raise RuntimeError(
                "CMake and pybind11 >= 2.11 must be installed to build the following extensions: "
                + ", ".join(e.name for e in self.extensions)
            )

        if platform.system() == "Windows":
            cmake_version = LooseVersion(
                re.search(r'version\s*([\d.]+)', out.decode()).group(1))
            if cmake_version < '3.1.0':
                raise RuntimeError("CMake >= 3.1.0 is required on Windows")

        for ext in self.extensions:
            self.build_extension(ext)

    def build_extension(self, ext):
        extdir = os.path.abspath(
            os.path.dirname(self.get_ext_fullpath(ext.name)))

        cmake_args = [
            f'-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}/{ext.package}',
            f'-DPYTHON_EXECUTABLE={sys.executable}',
            '-Dbuild_python_module=ON'
        ]

        cfg = 'Debug' if self.debug else 'Release'
        build_args = ['--config', cfg]

        if platform.system() == "Windows":
            cmake_args += [
                f'-DCMAKE_LIBRARY_OUTPUT_DIRECTORY_{cfg.upper()}={extdir}'
            ]
            if sys.maxsize > 2**32:
                cmake_args += ['-A', 'x64']
            build_args += ['--', '/m']
        else:
            cmake_args += [f'-DCMAKE_BUILD_TYPE={cfg}']
            build_args += ['--', f'-j{os.cpu_count()}']

        if "CUDA_ROOT" in os.environ:
            if os.path.isfile(f'{os.environ["CUDA_ROOT"]}/bin/gcc'):
                cmake_args += [
                    f'-DCMAKE_C_COMPILER={os.environ["CUDA_ROOT"]}/bin/gcc']
            if os.path.isfile(f'{os.environ["CUDA_ROOT"]}/bin/g++'):
                cmake_args += [
                    f'-DCMAKE_CXX_COMPILER={os.environ["CUDA_ROOT"]}/bin/g++']
            cmake_args += ['-DUSE_CUDA=ON']
        else:
            cmake_args += ['-DUSE_CUDA=OFF']

        os.makedirs(self.build_temp, exist_ok=True)

        subprocess.check_call(['cmake', ext.sourcedir] + cmake_args,
                              cwd=self.build_temp)
        subprocess.check_call(['cmake', '--build', '.'] + build_args,
                              cwd=self.build_temp)


with open("README.md", 'r') as f:
    long_description = f.read()

setup(
    name="pyMilk",
    version="0.1",
    packages=['pyMilk', 'pyMilk.interfacing'],
    ext_modules=[CMakeExtension('ImageStreamIOWrap', package='pyMilk')],
    cmdclass={'build_ext': CMakeBuildExt},
    long_description=long_description,
    long_description_content_type='text/markdown'
)

