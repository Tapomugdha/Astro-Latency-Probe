/**
 * @file    applyPF.h
 * @brief   Apply predictive filter
 *
 *
 */

#ifndef LINARFILTERPRED_APPLYPF_H
#define LINARFILTERPRED_APPLYPF_H

errno_t CLIADDCMD_LinARfilterPred__applyPF();

#endif
