#ifndef LINARFILTERPRED_BUILD_LINPF_H
#define LINARFILTERPRED_BUILD_LINPF_H

errno_t CLIADDCMD_LinARfilterPred__build_linPF();

#endif
