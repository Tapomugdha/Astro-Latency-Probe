[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/1b0fa47b6ae84336bb46214604ae519d)](https://www.codacy.com/gh/milk-org/linARfilterPred?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/linARfilterPred&amp;utm_campaign=Badge_Grade)


# Module linARfilterPred {#page_module_linARfilterPred}

Linear AutoRegressive prediction filter
