#ifndef CLUSTERING__NODE_ATTACHNODE_H
#define CLUSTERING__NODE_ATTACHNODE_H

errno_t node_attachnode(CLUSTERTREE *ctree, long CFindex, long CFindexupnode);

#endif
