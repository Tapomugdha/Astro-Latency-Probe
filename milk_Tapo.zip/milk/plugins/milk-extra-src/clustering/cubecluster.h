#ifndef CLUSTERING__CUBECLUSTER_H
#define CLUSTERING__CUBECLUSTER_H

errno_t CLIADDCMD_clustering__imcube_mkcluster();

#endif
