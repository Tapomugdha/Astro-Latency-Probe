#ifndef CLUSTERING__CFTREE_REBUILD_H
#define CLUSTERING__CFTREE_REBUILD_H

errno_t
CFtree_rebuild(CLUSTERTREE *ctree, long *frameleafCFindex, long NBframe);

#endif
