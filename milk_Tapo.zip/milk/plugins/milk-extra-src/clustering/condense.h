#ifndef CLUSTERING__CONDENSE_H
#define CLUSTERING__CONDENSE_H

errno_t ctree_condense(CLUSTERTREE *ctree, int *nbop);

#endif
