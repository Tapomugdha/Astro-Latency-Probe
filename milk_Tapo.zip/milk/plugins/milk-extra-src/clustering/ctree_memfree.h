#ifndef CLUSTERING__CTREE_MEMFREE_H
#define CLUSTERING__CTREE_MEMFREE_H

errno_t ctree_memfree(CLUSTERTREE *ctree);

#endif
