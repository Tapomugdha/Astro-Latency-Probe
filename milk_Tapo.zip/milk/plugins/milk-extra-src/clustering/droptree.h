#ifndef CLUSTERING__DROPTREE_H
#define CLUSTERING__DROPTREE_H

errno_t droptree(CLUSTERTREE *ctree);

#endif
