#ifndef CLUSTERING__LEAFNODE_ATTACHLEAF_H
#define CLUSTERING__LEAFNODE_ATTACHLEAF_H

errno_t node_attachleaf(CLUSTERTREE *ctree, long CFindexleaf, long CFindexnode);

#endif
