#ifndef CLUSTERING__MINDIFFSCAN_H
#define CLUSTERING__MINDIFFSCAN_H

errno_t CLIADDCMD_clustering__imcube_mindiffscan();

#endif
