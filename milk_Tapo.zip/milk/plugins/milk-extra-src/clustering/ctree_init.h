#ifndef CLUSTERING__CTREE_INIT_H
#define CLUSTERING__CTREE_INIT_H

errno_t ctree_init(CLUSTERTREE *ctree, double *datavector, long double ssqr);

#endif
