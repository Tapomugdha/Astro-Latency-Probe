#ifndef CLUSTERING__CTREE_MEMALLOCATE_H
#define CLUSTERING__CTREE_MEMALLOCATE_H

errno_t ctree_memallocate(CLUSTERTREE *ctree);

#endif
