#ifndef CLUSTERING__SPLIT_CF_NODE_H
#define CLUSTERING__SPLIT_CF_NODE_H

errno_t split_CF_node(CLUSTERTREE *ctree, long CFindex, long *CFi0, long *CFi1);

#endif
