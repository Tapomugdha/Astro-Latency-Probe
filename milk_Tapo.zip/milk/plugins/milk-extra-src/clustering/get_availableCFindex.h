#ifndef CLUSTERING__GET_AVAILABLECFINDEX_H
#define CLUSTERING__GET_AVAILABLECFINDEX_H

errno_t get_availableCFindex(CLUSTERTREE *ctree, long *index);

#endif
