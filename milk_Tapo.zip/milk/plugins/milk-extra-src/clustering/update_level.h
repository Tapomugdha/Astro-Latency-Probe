#ifndef CLUSTERING__UPDATE_LEVEL_H
#define CLUSTERING__UPDATE_LEVEL_H

errno_t update_level(CLUSTERTREE *ctree, long CFindex);

#endif
