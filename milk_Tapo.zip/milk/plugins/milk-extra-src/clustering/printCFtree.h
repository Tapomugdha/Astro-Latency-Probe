#ifndef CLUSTERING_PRINTCFTREE
#define CLUSTERING_PRINTCFTREE

errno_t printCFtree(CLUSTERTREE *ctree);

#endif
