#ifndef CLUSTERING__CFMEMINIT_H
#define CLUSTERING__CFMEMINIT_H

#define CFMEMINIT_CFUPDATE 0x0001

errno_t CFmeminit(CLUSTERTREE *ctree, long CFindex, uint32_t mode);

#endif
