/** @file testfftspeed.h
 */

errno_t testfftspeed_addCLIcmd();

int test_fftspeed(int nmax);
