/**
 * @file    fft_autocorrelation.h
 *
 */

imageID autocorrelation(const char *IDin_name, const char *IDout_name);
