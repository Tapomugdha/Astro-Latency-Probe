/** @file permut.h
 */

errno_t permut_addCLIcmd();

int permut(const char *ID_name);
