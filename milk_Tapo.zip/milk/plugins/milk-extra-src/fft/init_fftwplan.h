/**
 * @file init_fftwplan.h
 */

errno_t init_fftwplan_addCLIcmd();

errno_t init_fftw_plans(int mode);
errno_t init_fftw_plans0();
