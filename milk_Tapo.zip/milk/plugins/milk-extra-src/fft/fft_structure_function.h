/**
 * @file    fft_structure_function.h
 *
 */

imageID fft_structure_function(const char *ID_in, const char *ID_out);
