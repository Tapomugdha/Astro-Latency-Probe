/** @file fftzoom.h
 */

int fftzoom(const char *ID_name, const char *ID_out, long factor);

int fftczoom(const char *ID_name, const char *ID_out, long factor);
