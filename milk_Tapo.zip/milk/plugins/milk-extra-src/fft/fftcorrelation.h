/** @file fftcorrelation.c
 */

errno_t fftcorrelation_addCLIcmd();

imageID fft_correlation(const char *ID_name1,
                        const char *ID_name2,
                        const char *ID_nameout);
