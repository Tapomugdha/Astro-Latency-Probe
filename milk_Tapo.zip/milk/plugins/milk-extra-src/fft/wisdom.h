/**
 * @file wisdom.h
 */

errno_t import_wisdom();

errno_t export_wisdom();
