[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/9bca8b4a43484077baa5dcdcaa16760b)](https://www.codacy.com/gh/milk-org/img_reduce?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/img_reduce&amp;utm_campaign=Badge_Grade)

# Module img_reduce {#page_module_img_reduce}

Image analysis.
