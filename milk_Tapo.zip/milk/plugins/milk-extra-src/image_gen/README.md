[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/ff5f469398994615a47c98d15f23652d)](https://www.codacy.com/gh/milk-org/image_gen?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/image_gen&amp;utm_campaign=Badge_Grade)

# Module image_gen {#page_module_image_gen}

Generate test images, useful images.
