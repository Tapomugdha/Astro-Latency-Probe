
#ifndef IMAGE_GEN_MKRANDOMIM_H
#define IMAGE_GEN_MKRANDOMIM_H

errno_t CLIADDCMD_image_gen__mkrandomim();

#endif
