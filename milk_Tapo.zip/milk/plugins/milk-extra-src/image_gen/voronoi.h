
#ifndef IMAGE_GEN_VORONOI_H
#define IMAGE_GEN_VORONOI_H

errno_t CLIADDCMD_image_gen__voronoi();

#endif
