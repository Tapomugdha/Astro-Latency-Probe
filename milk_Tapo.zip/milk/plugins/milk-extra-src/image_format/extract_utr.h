#ifndef UPTHERAMP_CRED_CDS_UTR_H
#define UPTHERAMP_CRED_CDS_UTR_H

errno_t CLIADDCMD_image_format__cred_cds_utr();

#endif // UPTHERAMP_CRED_CDS_UTR_H
