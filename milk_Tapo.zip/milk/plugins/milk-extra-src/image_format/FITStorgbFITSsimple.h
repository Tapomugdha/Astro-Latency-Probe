/** @file FITStorgbFITSsimple.h
 */

errno_t convert_rawbayerFITStorgbFITS_simple(const char *__restrict ID_name,
        const char *__restrict ID_name_r,
        const char *__restrict ID_name_g,
        const char *__restrict ID_name_b,
        int SamplFactor);
