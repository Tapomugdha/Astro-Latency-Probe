/** @file extract_RGGBchan.h
 */

#ifndef IMAGEFORMAT_EXTRACTRGGBCHAN
#define IMAGEFORMAT_EXTRACTRGGBCHAN

errno_t CLIADDCMD_image_format__extractRGGBchan();

//errno_t extract_RGGBchan_addCLIcmd();
/*
errno_t image_format_extract_RGGBchan(const char *__restrict ID_name,
                                      const char *__restrict IDoutR_name,
                                      const char *__restrict IDoutG1_name,
                                      const char *__restrict IDoutG2_name,
                                      const char *__restrict IDoutB_name);
*/
#endif
