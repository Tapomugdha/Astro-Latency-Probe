[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/218632f8ae6c42919c00c410c2582fdb)](https://www.codacy.com/gh/milk-org/image_format?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/image_format&amp;utm_campaign=Badge_Grade)


# Module image_format {#page_module_image_format}

Read and write images, supports several image formats.
