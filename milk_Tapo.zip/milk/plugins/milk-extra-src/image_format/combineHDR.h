#ifndef IMAGE_FORMAT_COMBINEHDR_H
#define IMAGE_FORMAT_COMBINEHDR_H

errno_t CLIADDCMD_image_format__combineHDR();

#endif
