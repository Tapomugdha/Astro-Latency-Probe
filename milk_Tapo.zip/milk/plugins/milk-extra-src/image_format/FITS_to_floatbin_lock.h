/** @file FITS_to_floatbin_lock.h
 */

errno_t FITS_to_floatbin_lock_addCLIcmd();

imageID IMAGE_FORMAT_FITS_to_floatbin_lock(const char *__restrict IDname,
        const char *__restrict fname);
