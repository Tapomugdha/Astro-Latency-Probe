#ifndef STREAM_TEMPORAL_STATS_H
#define STREAM_TEMPORAL_STATS_H

errno_t CLIADDCMD_image_format__temporal_stats();

#endif // STREAM_TEMPORAL_STATS_H
