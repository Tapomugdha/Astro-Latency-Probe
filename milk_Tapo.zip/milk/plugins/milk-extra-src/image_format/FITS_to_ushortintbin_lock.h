/** @file FITS_to_ushortintbin_lock.h
 */

errno_t FITS_to_ushortintbin_lock_addCLIcmd();

imageID IMAGE_FORMAT_FITS_to_ushortintbin_lock(const char *__restrict IDname,
        const char *__restrict fname);
