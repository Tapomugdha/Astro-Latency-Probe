/** @file readPGM.h
 */

imageID read_PGMimage(const char *__restrict fname,
                      const char *__restrict ID_name);
