/** @file imtoASCII.h
 */

errno_t imtoASCII_addCLIcmd();

errno_t IMAGE_FORMAT_im_to_ASCII(const char *__restrict IDname,
                                 const char *__restrict foutname);
