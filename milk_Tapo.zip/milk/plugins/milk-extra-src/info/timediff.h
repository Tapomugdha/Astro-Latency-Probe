/** @file timediff.h
 */

struct timespec info_time_diff(struct timespec start, struct timespec end);
