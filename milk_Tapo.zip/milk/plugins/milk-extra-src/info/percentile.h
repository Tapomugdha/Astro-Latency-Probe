/** @file percentile.h
 */

float img_percentile_float(const char *ID_name, float p);

double img_percentile_double(const char *ID_name, double p);

double img_percentile(const char *ID_name, double p);
