/** @file cubeMatchMatrix.h
 */

errno_t cubeMatchMatrix_addCLIcmd();

imageID info_cubeMatchMatrix(const char *IDin_name, const char *IDout_name);
