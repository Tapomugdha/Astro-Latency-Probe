/** @file cubestats.h
 */

errno_t cubestats_addCLIcmd();

imageID info_cubestats(const char *ID_name,
                       const char *IDmask_name,
                       const char *outfname);
