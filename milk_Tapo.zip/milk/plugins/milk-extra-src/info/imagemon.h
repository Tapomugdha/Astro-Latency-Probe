/**
 * @file    imagemon.h
 */

#ifndef _INFO_IMAGEMON_H
#define _INFO_IMAGEMON_H

errno_t CLIADDCMD_info__imagemon();

#endif
