/** @file image_stats.h
 */

errno_t image_stats_addCLIcmd();

errno_t info_image_stats(const char *ID_name, const char *options);
