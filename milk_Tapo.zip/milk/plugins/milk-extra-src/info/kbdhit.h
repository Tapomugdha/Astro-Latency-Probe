/** @file kbdhit.h
 */

errno_t kbdhit(void);
