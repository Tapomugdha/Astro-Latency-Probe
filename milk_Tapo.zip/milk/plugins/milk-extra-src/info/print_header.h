/** @file print_header.h
 */

errno_t print_header(const char *str, char c);
