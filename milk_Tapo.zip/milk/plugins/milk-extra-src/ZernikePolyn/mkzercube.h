/**
 * @file mkzercube.h
 *
 */


#ifndef ZERNIKEPOLYN_MKZERCUBE_H
#define ZERNIKEPOLYN_MKZERCUBE_H

errno_t CLIADDCMD_ZernikePolyn__mkzercube();

#endif
