#ifndef LINOPTIMTOOLS_CROSSPRODUCT_H
#define LINOPTIMTOOLS_CROSSPRODUCT_H

errno_t CLIADDCMD_linopt_imtools__imcube_crossproduct();

#endif
