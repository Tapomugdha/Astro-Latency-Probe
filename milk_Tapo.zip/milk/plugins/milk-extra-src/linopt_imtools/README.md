[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/819e6651c443401c9ac1faf05e79faf6)](https://www.codacy.com/gh/milk-org/linopt_imtools?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/linopt_imtools&amp;utm_campaign=Badge_Grade)


# Module linopt_imtools {#page_module_linopt_imtools}

Linear analsys of images.
