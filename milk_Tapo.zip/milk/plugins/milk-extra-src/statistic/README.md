[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/2cace1103a57462a8ca6a39741b81062)](https://www.codacy.com/gh/milk-org/statistic?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/statistic&amp;utm_campaign=Badge_Grade)

# Module statistic {#page_module_statistic}

Statistical analysis tools
