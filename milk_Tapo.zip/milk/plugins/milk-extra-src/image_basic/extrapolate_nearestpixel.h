/** @file extrapolate_nearestpixel.h
 */

imageID basic_2Dextrapolate_nearestpixel(const char *__restrict IDin_name,
        const char *__restrict IDmask_name,
        const char *__restrict IDout_name);
