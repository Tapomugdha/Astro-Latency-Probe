[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/144f08609d5a4e32a5ec4060a2197436)](https://www.codacy.com/gh/milk-org/image_basic?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/image_basic&amp;utm_campaign=Badge_Grade)


# Module image_basic {#page_module_image_basic}

Frequently used image functions
