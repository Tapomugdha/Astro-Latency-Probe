/** @file naninf2zero.h
 */

int basic_naninf2zero(const char *ID_name);
