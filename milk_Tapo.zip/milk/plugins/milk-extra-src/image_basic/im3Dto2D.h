/** @file im3Dto2D.h
 */

errno_t __attribute__((cold)) im3Dto2D_addCLIcmd();

imageID image_basic_3Dto2D_byID(imageID ID);

imageID image_basic_3Dto2D(const char *__restrict IDname);
