/** @file measure_transl.h
 */

double basic_measure_transl(const char *__restrict ID_name1,
                            const char *__restrict ID_name2,
                            long tmax);
