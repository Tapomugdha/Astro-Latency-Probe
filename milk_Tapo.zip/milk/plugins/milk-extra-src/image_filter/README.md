[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/5a85401ff3f94c6983bbd0b01dd14cd2)](https://www.codacy.com/gh/milk-org/image_filter?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/image_filter&amp;utm_campaign=Badge_Grade)

# Module image_filter {#page_module_image_filter}

Image filtering and convolution
