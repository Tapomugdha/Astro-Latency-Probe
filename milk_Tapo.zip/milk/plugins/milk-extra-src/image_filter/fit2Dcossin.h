/** @file fit2Dcossin.h
 */

int filter_fit2Dcossin(const char *__restrict IDname, float radius);
