/** @file fit1D.h
 */

int filter_fit1D(const char *__restrict fname, long NBpts);
