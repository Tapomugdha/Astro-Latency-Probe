/** @file medianfilter.h
 */

imageID median_filter(const char *__restrict ID_name,
                      const char *__restrict out_name,
                      int filter_size);
