/** @file fit2DcosKernel.h
 */

errno_t filter_fit2DcosKernel(const char *__restrict IDname, float radius);
