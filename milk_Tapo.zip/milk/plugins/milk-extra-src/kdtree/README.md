[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/aadc4a20347f4d43b619bfb3a92ceb0f)](https://www.codacy.com/gh/milk-org/kdtree?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/kdtree&amp;utm_campaign=Badge_Grade)

# Module kdtree {#page_module_kdtree}

kdtree
