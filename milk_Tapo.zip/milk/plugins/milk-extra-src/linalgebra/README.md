# Module linalgebra

Light interface to linea algebra libs (BLAS, CUDA and MAGMA)
