/** @file GPUloadCmat.h
 */

#ifdef HAVE_CUDA

errno_t GPUloadCmat(int index);

#endif
