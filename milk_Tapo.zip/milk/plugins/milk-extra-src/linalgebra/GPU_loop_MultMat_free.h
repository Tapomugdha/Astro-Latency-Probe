/** @file GPU_loop_MultMat_free.h
 */

#ifdef HAVE_CUDA

int GPU_loop_MultMat_free(int index);

#endif
