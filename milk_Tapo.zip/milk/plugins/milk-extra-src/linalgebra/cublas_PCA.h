
#ifndef LINALGEBRA_PCA_H
#define LINALGEBRA_PCA_H

errno_t CLIADDCMD_linalgebra__PCAdecomp();

#endif
