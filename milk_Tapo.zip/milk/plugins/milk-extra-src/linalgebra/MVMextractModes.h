#ifndef LINALGEBRA_MVMEXTRACTMODES_H
#define LINALGEBRA_MVMEXTRACTMODES_H

errno_t CLIADDCMD_linalgebra__MVMextractModes();

#endif
