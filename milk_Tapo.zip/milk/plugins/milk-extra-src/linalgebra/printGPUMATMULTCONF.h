/** @file printGPUMATMULTCONF.h
 */

#ifdef HAVE_CUDA

errno_t LINALGEBRA_printGPUMATMULTCONF(int index);

#endif
