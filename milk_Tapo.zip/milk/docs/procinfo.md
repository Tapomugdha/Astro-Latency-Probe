# Process Information (procinfo)

procinfo is
