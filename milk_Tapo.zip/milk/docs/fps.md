# Function Parameter Structure (FPS)

FPS is
