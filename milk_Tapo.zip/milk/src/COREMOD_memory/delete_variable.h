/** @file delete_variable.h
 */

errno_t delete_variable_ID(const char *varname);
