/**
 * @file    compute_nb_image.h
 */

long compute_nb_image();
