/**
 * @file    fps_list.h
 */

errno_t fps_list_addCLIcmd();

errno_t fps_list();
