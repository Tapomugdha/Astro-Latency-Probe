/** @file clearall.h
 */

errno_t clearall_addCLIcmd();

errno_t clearall();
