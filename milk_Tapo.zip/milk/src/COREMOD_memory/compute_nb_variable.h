/**
 * @file    compute_nb_variable.h
 */

long compute_nb_variable();
