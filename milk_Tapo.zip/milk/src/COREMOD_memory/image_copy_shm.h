#ifndef COREMOD_MEMORY_IMAGE_COPY_SHM_H
#define COREMOD_MEMORY_IMAGE_COPY_SHM_H

errno_t CLIADDCMD_COREMOD_memory__image_copy_shm();

#endif
