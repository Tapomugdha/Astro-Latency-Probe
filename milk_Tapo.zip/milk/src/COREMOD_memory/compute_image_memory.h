/**
 * @file    compute_image_memory.h
 */

uint64_t compute_image_memory();
