[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/80767f11ee1b48d496966e4c3bdd7d53)](https://www.codacy.com/gh/milk-org/COREMOD_memory?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/COREMOD_memory&amp;utm_campaign=Badge_Grade)

# Module COREMOD_memory {#page_module_COREMOD_memory}

Memory management for images
