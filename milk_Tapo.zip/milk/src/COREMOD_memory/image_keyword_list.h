#ifndef COREMOD_MEMORY_IMAGE_KEYWORD_LIST_H
#define COREMOD_MEMORY_IMAGE_KEYWORD_LIST_H

errno_t image_keywords_list(IMGID img);

errno_t CLIADDCMD_COREMOD_memory__image_keyword_list();

#endif
