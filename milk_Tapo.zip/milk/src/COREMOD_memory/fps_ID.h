/**
 * @file    fps_ID.h
 */

long fps_ID(const char *name);

long next_avail_fps_ID();
