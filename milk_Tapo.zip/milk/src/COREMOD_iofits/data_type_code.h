/**
 * @file    data_type_code.h
 */

int data_type_code(int bitpix);
