/**
 * @file    is_fits_file.h
 */

int is_fits_file(const char *restrict file_name);
