/**
 * @file    file_exists.h
 */

int file_exists(const char *restrict file_name);
