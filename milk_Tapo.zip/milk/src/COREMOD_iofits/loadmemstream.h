/**
 * @file    loadmemstream.h
 */

imageID COREMOD_IOFITS_LoadMemStream(const char *sname,
                                     uint64_t   *streamflag,
                                     uint32_t   *imLOC);
