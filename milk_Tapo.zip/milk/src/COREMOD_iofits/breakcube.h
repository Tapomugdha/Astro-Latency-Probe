/**
 * @file    breakcube.h
 */

errno_t breakcube_addCLIcmd();

imageID break_cube(const char *restrict ID_name);
