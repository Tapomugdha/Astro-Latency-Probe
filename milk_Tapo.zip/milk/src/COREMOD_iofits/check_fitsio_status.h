/**
 * @file    ckeck_fitsio_status.h
 */

int check_FITSIO_status(const char *restrict cfile,
                        const char *restrict cfunc,
                        long cline,
                        int  print);
