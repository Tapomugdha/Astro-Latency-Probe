[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/3ce1d87bf59e4be58f3093aac9196e97)](https://www.codacy.com/gh/milk-org/COREMOD_arith?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=milk-org/COREMOD_arith&amp;utm_campaign=Badge_Grade)

# Module COREMOD_arith {#page_module_COREMOD_arith}

Arith functions on images
