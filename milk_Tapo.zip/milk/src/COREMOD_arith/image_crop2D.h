#ifndef COREMOD_ARITH_CROP2D_H
#define COREMOD_ARITH_CROP2D_H

errno_t CLIADDCMD_COREMODE_arith__crop2D();

#endif
