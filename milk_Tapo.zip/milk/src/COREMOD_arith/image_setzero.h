#ifndef COREMOD_MODULE_ARITH_IMSETZERO_H
#define COREMOD_MODULE_ARITH_IMSETZERO_H


errno_t image_setzero(
    IMGID inimg
);

errno_t CLIADDCMD_COREMOD_arith__imsetzero();

#endif
