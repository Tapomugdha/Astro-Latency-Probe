#ifndef COREMOD_ARITH_PIXREMAP_H
#define COREMOD_ARITH_PIXREMAP_H

errno_t CLIADDCMD_COREMODE_arith__pixremap();

#endif
