#ifndef COREMOD_ARITH_PIXUNMAP_H
#define COREMOD_ARITH_PIXUNMAP_H

errno_t CLIADDCMD_COREMODE_arith__pixunmap();

#endif
