#ifndef COREMOD_ARITH_IMAGE_NORM_H
#define COREMOD_ARITH_IMAGE_NORM_H

errno_t CLIADDCMD_COREMOD_arith__image_normslice();

#endif
