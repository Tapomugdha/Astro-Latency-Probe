#ifndef COREMOD_ARITH_CROPMASK_H
#define COREMOD_ARITH_CROPMASK_H

errno_t CLIADDCMD_COREMODE_arith__cropmask();

#endif
