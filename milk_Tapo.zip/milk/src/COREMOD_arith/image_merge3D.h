/**
 * @file    image_merge3D.h
 *
 */


#ifndef COREMOD_ARITH__IMAGE_MERGE_H
#define COREMOD_ARITH__IMAGE_MERGE_H



errno_t
CLIADDCMD_COREMOD_arith__image_merge();

#endif
