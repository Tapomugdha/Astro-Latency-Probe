/**
 * @file    image_dxdy.c
 */

imageID arith_image_dx(const char *ID_name, const char *IDout_name);

imageID arith_image_dy(const char *ID_name, const char *IDout_name);
