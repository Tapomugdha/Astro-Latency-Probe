/**
 * @file    image_total.h
 *
 */

double arith_image_total(const char *ID_name);

double arith_image_sumsquare(const char *ID_name);
