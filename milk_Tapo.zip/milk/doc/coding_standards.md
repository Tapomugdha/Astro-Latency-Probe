# Coding Standards # {#page_coding_standards}

{#page_coding_standards}


@note This file: ./src/CommandLineInterface/doc/coding_standards.md

- @subpage page_ModuleFiles
- @subpage page_DocumentingCode
- @subpage page_TemplateSourceCode

- @subpage page_ProcessInfoStructure
- @subpage page_FunctionParameterStructure
- @subpage page_exampleBASHscript
