# Template Souce Code {#page_TemplateSourceCode}

Documentation should appear before each function in the .c and .h files, following these teamplates.


## .h file

<a href="../src/CommandLineInterface/doc/templatemodule/templatemodule.h">Download templatemodule.h</a>

See corresponding doxygen documentation : templatemodule/templatemodule.h


## .c file

<a href="../src/CommandLineInterface/doc/templatemodule/templatemodule.c">Download templatemodule.c</a>

See corresponding doxygen documentation : templatemodule/templatemodule.c
