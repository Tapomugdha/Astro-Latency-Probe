# CLI Overview {#page_CLI_Overview}

The entire C code is compiled into a single executable :

	./bin/<packagename>

Running the executable starts a command line interface (CLI) prompt from which all functions can be launched.

The source code is organized in modules. A module included C code and documentation. It may also include data files and extended documentation. Run `m?` in the CLI prompt to list modules.
