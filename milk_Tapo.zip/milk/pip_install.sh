python -m venv pyMilk

source pyMilk/bin/activate

pip install .
