//-----------------------------------------------------------------------------
//  Basler pylon
//  Copyright (c) 2014-2025 Basler AG
//  http://www.baslerweb.com
//-----------------------------------------------------------------------------

#pragma once

#define PYLON_VERSION_MAJOR           10
#define PYLON_VERSION_MINOR           2
#define PYLON_VERSION_SUBMINOR        1
#define PYLON_VERSION_BUILD           471

#define PYLON_VERSIONSTRING_MAJOR     "10"
#define PYLON_VERSIONSTRING_MINOR     "2"
#define PYLON_VERSIONSTRING_SUBMINOR  "1"
#define PYLON_VERSIONSTRING_BUILD     "471"
#define PYLON_VERSIONSTRING_EXTENSION ""

#define PYLON_VERSIONSTRING_GITHASH   "2f50e7b7"
