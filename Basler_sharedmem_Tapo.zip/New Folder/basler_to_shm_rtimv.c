#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <stdint.h>
#include <inttypes.h>
#include <fcntl.h>
#include <termios.h>
#include <pylonc/PylonC.h>
#include "ImageStreamIO.h"

#define STREAM_NAME "rtimv_live"
#define WIDTH 720
#define HEIGHT 540
#define BUFFER_COUNT 10

#define LED_X 100
#define LED_Y 100
#define LED_W 10
#define LED_H 10
#define LED_THRESHOLD 1

#define MAX_UDP_EVENTS 10
#define MAX_MATCH_WINDOW 10

#define SERIAL_PORT "/dev/ttyACM0"

volatile sig_atomic_t keep_running = 1;

typedef struct {
    int frame;
    uint64_t t1_pc_ms;
} LedEvent;

void handle_sigint(int sig) {
    (void)sig;
    keep_running = 0;
}

void print_last_error(const char* msg) {
    char errMsg[1024];
    size_t errLen = sizeof(errMsg);
    GenApiGetLastErrorMessage(errMsg, &errLen);
    fprintf(stderr, "%s\nPylon error: %s\n", msg, errMsg);
}

uint64_t get_time_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)(ts.tv_sec) * 1000 + (ts.tv_nsec / 1000000);
}

int setup_serial_port() {
    int fd = open(SERIAL_PORT, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("open serial port");
        exit(EXIT_FAILURE);
    }
    struct termios options;
    tcgetattr(fd, &options);
    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    tcsetattr(fd, TCSANOW, &options);
    fcntl(fd, F_SETFL, FNDELAY);
    return fd;
}

int main() {
    signal(SIGINT, handle_sigint);
    PylonInitialize();

    int serial_fd = setup_serial_port();
    LedEvent udp_event_frames[MAX_UDP_EVENTS];
    int udp_event_head = 0, udp_event_tail = 0;

    size_t numDevices = 0;
    if (PylonEnumerateDevices(&numDevices) != 0 || numDevices == 0) {
        print_last_error("No Basler cameras found.");
        PylonTerminate();
        return 1;
    }
    printf("Found %zu Basler device(s):\n", numDevices);
    for (size_t i = 0; i < numDevices; ++i) {
        PylonDeviceInfo_t di;
        if (PylonGetDeviceInfo(i, &di) == 0) {
            printf("  [%zu]: Model: %s, Serial: %s\n", i, di.ModelName, di.SerialNumber);
        } else {
            printf("  [%zu]: <Unknown device>\n", i);
        }
    }

    size_t deviceIndex = 0;
    if (numDevices > 1) {
        printf("Enter camera index to use [0-%zu]: ", numDevices - 1);
        fflush(stdout);
        if (scanf("%zu", &deviceIndex) != 1 || deviceIndex >= numDevices) {
            fprintf(stderr, "Invalid camera index.\n");
            PylonTerminate();
            return 1;
        }
    }

    PYLON_DEVICE_HANDLE hDev;
    if (PylonCreateDeviceByIndex(deviceIndex, &hDev) != 0) {
        print_last_error("Failed to create device.");
        PylonTerminate();
        return 1;
    }
    if (PylonDeviceOpen(hDev, PYLONC_ACCESS_MODE_CONTROL | PYLONC_ACCESS_MODE_STREAM) != 0) {
        print_last_error("Failed to open camera device.");
        PylonDestroyDevice(hDev);
        PylonTerminate();
        return 1;
    }

    if (PylonDeviceFeatureFromString(hDev, "PixelFormat", "Mono8") != 0)
        print_last_error("Warning: Failed to set PixelFormat.");
    PylonDeviceSetIntegerFeature(hDev, "Width", WIDTH);
    PylonDeviceSetIntegerFeature(hDev, "Height", HEIGHT);

    // ---- SET ONLY EXPOSURE TIME HERE ----
    double exposure_us = 2000.0; // or 2000.0, 4000.0, etc.
    PylonDeviceSetFloatFeature(hDev, "ExposureTime", exposure_us);

    // ---- DO NOT SET AcquisitionFrameRate ----
    PylonDeviceFeatureFromString(hDev, "AcquisitionMode", "Continuous");

    double actualFPS = 0.0;
    if (PylonDeviceGetFloatFeature(hDev, "ResultingFrameRate", &actualFPS) == 0)
        printf("Camera reports ResultingFrameRate: %.2f FPS\n", actualFPS);

    IMAGE im;
    uint32_t imsize[2] = {WIDTH, HEIGHT};
    if (ImageStreamIO_createIm(&im, STREAM_NAME, 2, imsize, _DATATYPE_UINT8, 1, 0, 1) != 0) {
        print_last_error("Failed to create shared memory image.");
        PylonDeviceClose(hDev);
        PylonDestroyDevice(hDev);
        PylonTerminate();
        return 1;
    }

    PYLON_STREAMGRABBER_HANDLE hGrabber;
    if (PylonDeviceGetStreamGrabber(hDev, 0, &hGrabber) != 0) {
        print_last_error("Failed to get stream grabber.");
        ImageStreamIO_destroyIm(&im);
        PylonDeviceClose(hDev);
        PylonDestroyDevice(hDev);
        PylonTerminate();
        return 1;
    }
    if (PylonStreamGrabberOpen(hGrabber) != 0) {
        print_last_error("Failed to open stream grabber.");
        ImageStreamIO_destroyIm(&im);
        PylonDeviceClose(hDev);
        PylonDestroyDevice(hDev);
        PylonTerminate();
        return 1;
    }

    size_t payloadSize = WIDTH * HEIGHT;
    PylonStreamGrabberSetMaxNumBuffer(hGrabber, BUFFER_COUNT);
    PylonStreamGrabberSetMaxBufferSize(hGrabber, payloadSize);

    if (PylonStreamGrabberPrepareGrab(hGrabber) != 0) {
        print_last_error("Failed to prepare grabber.");
        ImageStreamIO_destroyIm(&im);
        PylonDeviceClose(hDev);
        PylonDestroyDevice(hDev);
        PylonTerminate();
        return 1;
    }

    unsigned char* buffers[BUFFER_COUNT];
    PYLON_STREAMBUFFER_HANDLE bufHandles[BUFFER_COUNT];
    for (int i = 0; i < BUFFER_COUNT; ++i) {
        buffers[i] = (unsigned char*)malloc(payloadSize);
        if (!buffers[i]) {
            fprintf(stderr, "Out of memory.\n");
            exit(EXIT_FAILURE);
        }
        if (PylonStreamGrabberRegisterBuffer(hGrabber, buffers[i], payloadSize, &bufHandles[i]) != 0) {
            print_last_error("Failed to register buffer.");
            exit(EXIT_FAILURE);
        }
        if (PylonStreamGrabberQueueBuffer(hGrabber, bufHandles[i], (void*)(intptr_t)i) != 0) {
            print_last_error("Failed to queue buffer.");
            exit(EXIT_FAILURE);
        }
    }

    if (PylonDeviceExecuteCommandFeature(hDev, "AcquisitionStart") != 0) {
        print_last_error("Failed to start acquisition.");
        exit(EXIT_FAILURE);
    }
    PylonStreamGrabberStartStreamingIfMandatory(hGrabber);

    printf("Streaming live frames to %s @ %dx%d\n", STREAM_NAME, WIDTH, HEIGHT);
    printf("Press Ctrl+C to stop.\n");

    int frame = 0;
    int frames_in_window = 0;
    struct timespec t_window_start, t_now;
    clock_gettime(CLOCK_MONOTONIC, &t_window_start);

    int led_prev_state = 0;
    int led_on_frame = -1;

    char serial_buf[128];
    int serial_buf_pos = 0;

    static double current_fps = 1000.0; // Start with a high guess

    while (keep_running) {
        // --- Serial Receive (non-blocking, line-based) ---
        int n = read(serial_fd, &serial_buf[serial_buf_pos], sizeof(serial_buf) - serial_buf_pos - 1);
        if (n > 0) {
            serial_buf_pos += n;
            serial_buf[serial_buf_pos] = '\0';
            char *newline;
            while ((newline = strchr(serial_buf, '\n')) != NULL) {
                *newline = '\0';
                if (strstr(serial_buf, "LED_ON")) {
                    udp_event_frames[udp_event_tail].frame = frame + 1;
                    udp_event_frames[udp_event_tail].t1_pc_ms = get_time_ms();
                    udp_event_tail = (udp_event_tail + 1) % MAX_UDP_EVENTS;
                }
                serial_buf_pos -= (newline - serial_buf + 1);
                memmove(serial_buf, newline + 1, serial_buf_pos);
                serial_buf[serial_buf_pos] = '\0';
            }
        }

        PylonGrabResult_t grabResult;
        _Bool isReady;
        if (PylonStreamGrabberRetrieveResult(hGrabber, &grabResult, &isReady) != 0 || !isReady) {
            usleep(100);
            continue;
        }
        if (grabResult.Status == Grabbed) {
            int bufIdx = (int)(intptr_t)grabResult.Context;
            unsigned char* pBuffer = buffers[bufIdx];
            memcpy(im.array.UI8, pBuffer, payloadSize);
            im.md->cnt0++;
            ImageStreamIO_semflush(&im, 0);
            ImageStreamIO_sempost(&im, 0);

            frame++;
            frames_in_window++;

            int sum = 0;
            for (int y = LED_Y; y < LED_Y + LED_H; ++y) {
                for (int x = LED_X; x < LED_X + LED_W; ++x) {
                    sum += im.array.UI8[y * WIDTH + x];
                }
            }
            int avg = sum / (LED_W * LED_H);
            int led_state = (avg > LED_THRESHOLD) ? 1 : 0;

            if (led_state == 1 && led_prev_state == 0) {
                led_on_frame = frame;
                uint64_t t2_pc = get_time_ms();
                while (udp_event_head != udp_event_tail) {
                    int event_frame = udp_event_frames[udp_event_head].frame;
                    uint64_t t1_pc = udp_event_frames[udp_event_head].t1_pc_ms;
                    int latency_frames = led_on_frame - event_frame;
                    if (latency_frames >= 1 && latency_frames <= MAX_MATCH_WINDOW) {
                        double latency_ms = latency_frames * 1000.0 / current_fps;
                        printf("t1: %" PRIu64 " ms, t2: %" PRIu64 " ms\n", t1_pc, t2_pc);
                        printf("LED ON detected at frame %d, TRUE LATENCY: %d frames (%.6f ms)\n",
                            led_on_frame, latency_frames, latency_ms);
                        udp_event_head = (udp_event_head + 1) % MAX_UDP_EVENTS;
                        break;
                    } else if (latency_frames > MAX_MATCH_WINDOW) {
                        udp_event_head = (udp_event_head + 1) % MAX_UDP_EVENTS;
                    } else {
                        break;
                    }
                }
            }
            led_prev_state = led_state;

            clock_gettime(CLOCK_MONOTONIC, &t_now);
            double elapsed_sec = (t_now.tv_sec - t_window_start.tv_sec) + (t_now.tv_nsec - t_window_start.tv_nsec) / 1e9;
            if (elapsed_sec >= 1.0) {
                current_fps = frames_in_window / elapsed_sec;
                printf("Average FPS over last %.2f s: %.2f\n", elapsed_sec, current_fps);
                frames_in_window = 0;
                t_window_start = t_now;
            }
        }
        PylonStreamGrabberQueueBuffer(hGrabber, grabResult.hBuffer, grabResult.Context);
    }

    PylonStreamGrabberStopStreamingIfMandatory(hGrabber);
    PylonStreamGrabberFinishGrab(hGrabber);
    PylonDeviceExecuteCommandFeature(hDev, "AcquisitionStop");
    PylonStreamGrabberClose(hGrabber);
    for (int i = 0; i < BUFFER_COUNT; ++i) {
        free(buffers[i]);
    }
    ImageStreamIO_destroyIm(&im);
    PylonDeviceClose(hDev);
    PylonDestroyDevice(hDev);
    PylonTerminate();
    close(serial_fd);

    printf("\nCamera stream stopped.\n");
    return 0;
}

