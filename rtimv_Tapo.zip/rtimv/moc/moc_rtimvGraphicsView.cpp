/****************************************************************************
** Meta object code from reading C++ file 'rtimvGraphicsView.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../src/rtimvGraphicsView.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rtimvGraphicsView.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_rtimvGraphicsView_t {
    QByteArrayData data[14];
    char stringdata0[161];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_rtimvGraphicsView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_rtimvGraphicsView_t qt_meta_stringdata_rtimvGraphicsView = {
    {
QT_MOC_LITERAL(0, 0, 17), // "rtimvGraphicsView"
QT_MOC_LITERAL(1, 18, 13), // "centerChanged"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 18), // "mouseCoordsChanged"
QT_MOC_LITERAL(4, 52, 11), // "leftPressed"
QT_MOC_LITERAL(5, 64, 2), // "mp"
QT_MOC_LITERAL(6, 67, 11), // "leftClicked"
QT_MOC_LITERAL(7, 79, 12), // "rightPressed"
QT_MOC_LITERAL(8, 92, 12), // "rightClicked"
QT_MOC_LITERAL(9, 105, 10), // "wheelMoved"
QT_MOC_LITERAL(10, 116, 5), // "delta"
QT_MOC_LITERAL(11, 122, 12), // "zoomTimerOut"
QT_MOC_LITERAL(12, 135, 11), // "resizeEvent"
QT_MOC_LITERAL(13, 147, 13) // "QResizeEvent*"

    },
    "rtimvGraphicsView\0centerChanged\0\0"
    "mouseCoordsChanged\0leftPressed\0mp\0"
    "leftClicked\0rightPressed\0rightClicked\0"
    "wheelMoved\0delta\0zoomTimerOut\0resizeEvent\0"
    "QResizeEvent*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_rtimvGraphicsView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,
       3,    0,   60,    2, 0x06 /* Public */,
       4,    1,   61,    2, 0x06 /* Public */,
       6,    1,   64,    2, 0x06 /* Public */,
       7,    1,   67,    2, 0x06 /* Public */,
       8,    1,   70,    2, 0x06 /* Public */,
       9,    1,   73,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    0,   76,    2, 0x09 /* Protected */,
      12,    1,   77,    2, 0x09 /* Protected */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPointF,    5,
    QMetaType::Void, QMetaType::QPointF,    5,
    QMetaType::Void, QMetaType::QPointF,    5,
    QMetaType::Void, QMetaType::QPointF,    5,
    QMetaType::Void, QMetaType::Int,   10,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 13,    2,

       0        // eod
};

void rtimvGraphicsView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<rtimvGraphicsView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->centerChanged(); break;
        case 1: _t->mouseCoordsChanged(); break;
        case 2: _t->leftPressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 3: _t->leftClicked((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 4: _t->rightPressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 5: _t->rightClicked((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 6: _t->wheelMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->zoomTimerOut(); break;
        case 8: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (rtimvGraphicsView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::centerChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::mouseCoordsChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)(QPointF );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::leftPressed)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)(QPointF );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::leftClicked)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)(QPointF );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::rightPressed)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)(QPointF );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::rightClicked)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (rtimvGraphicsView::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvGraphicsView::wheelMoved)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject rtimvGraphicsView::staticMetaObject = { {
    QMetaObject::SuperData::link<QGraphicsView::staticMetaObject>(),
    qt_meta_stringdata_rtimvGraphicsView.data,
    qt_meta_data_rtimvGraphicsView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *rtimvGraphicsView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *rtimvGraphicsView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_rtimvGraphicsView.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsView::qt_metacast(_clname);
}

int rtimvGraphicsView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void rtimvGraphicsView::centerChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void rtimvGraphicsView::mouseCoordsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void rtimvGraphicsView::leftPressed(QPointF _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void rtimvGraphicsView::leftClicked(QPointF _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void rtimvGraphicsView::rightPressed(QPointF _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void rtimvGraphicsView::rightClicked(QPointF _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void rtimvGraphicsView::wheelMoved(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
