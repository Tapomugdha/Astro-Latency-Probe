/****************************************************************************
** Meta object code from reading C++ file 'cubeCtrl.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../src/cubeCtrl.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'cubeCtrl.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cubeCtrl_t {
    QByteArrayData data[49];
    char stringdata0[922];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_cubeCtrl_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_cubeCtrl_t qt_meta_stringdata_cubeCtrl = {
    {
QT_MOC_LITERAL(0, 0, 8), // "cubeCtrl"
QT_MOC_LITERAL(1, 9, 15), // "cubeModeUpdated"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 14), // "cubeFPSUpdated"
QT_MOC_LITERAL(4, 41, 18), // "cubeFPSMultUpdated"
QT_MOC_LITERAL(5, 60, 14), // "cubeDirUpdated"
QT_MOC_LITERAL(6, 75, 16), // "cubeFrameUpdated"
QT_MOC_LITERAL(7, 92, 8), // "uint32_t"
QT_MOC_LITERAL(8, 101, 21), // "cubeFrameDeltaUpdated"
QT_MOC_LITERAL(9, 123, 7), // "int32_t"
QT_MOC_LITERAL(10, 131, 16), // "autoScaleUpdated"
QT_MOC_LITERAL(11, 148, 8), // "cubeMode"
QT_MOC_LITERAL(12, 157, 4), // "mode"
QT_MOC_LITERAL(13, 162, 7), // "cubeFPS"
QT_MOC_LITERAL(14, 170, 3), // "fps"
QT_MOC_LITERAL(15, 174, 10), // "desiredFPS"
QT_MOC_LITERAL(16, 185, 11), // "cubeFPSMult"
QT_MOC_LITERAL(17, 197, 2), // "fm"
QT_MOC_LITERAL(18, 200, 7), // "cubeDir"
QT_MOC_LITERAL(19, 208, 1), // "d"
QT_MOC_LITERAL(20, 210, 9), // "autoScale"
QT_MOC_LITERAL(21, 220, 2), // "as"
QT_MOC_LITERAL(22, 223, 30), // "on_lineEditFPS_editingFinished"
QT_MOC_LITERAL(23, 254, 28), // "on_lineEditFPS_returnPressed"
QT_MOC_LITERAL(24, 283, 23), // "on_buttonFPSD10_pressed"
QT_MOC_LITERAL(25, 307, 22), // "on_buttonFPSD2_pressed"
QT_MOC_LITERAL(26, 330, 22), // "on_buttonFPSX2_pressed"
QT_MOC_LITERAL(27, 353, 23), // "on_buttonFPSX10_pressed"
QT_MOC_LITERAL(28, 377, 33), // "on_buttonFastFastBackward_pre..."
QT_MOC_LITERAL(29, 411, 29), // "on_buttonFastBackward_pressed"
QT_MOC_LITERAL(30, 441, 29), // "on_buttonPlayBackward_pressed"
QT_MOC_LITERAL(31, 471, 21), // "on_buttonStop_pressed"
QT_MOC_LITERAL(32, 493, 28), // "on_buttonPlayForward_pressed"
QT_MOC_LITERAL(33, 522, 28), // "on_buttonFastForward_pressed"
QT_MOC_LITERAL(34, 551, 32), // "on_buttonFastFastForward_pressed"
QT_MOC_LITERAL(35, 584, 32), // "on_lineEditFrame_editingFinished"
QT_MOC_LITERAL(36, 617, 30), // "on_lineEditFrame_returnPressed"
QT_MOC_LITERAL(37, 648, 29), // "on_scrollBarFrame_sliderMoved"
QT_MOC_LITERAL(38, 678, 5), // "value"
QT_MOC_LITERAL(39, 684, 32), // "on_scrollBarFrame_sliderReleased"
QT_MOC_LITERAL(40, 717, 32), // "on_buttonFrameDecrement2_pressed"
QT_MOC_LITERAL(41, 750, 31), // "on_buttonFrameDecrement_pressed"
QT_MOC_LITERAL(42, 782, 31), // "on_buttonFrameIncrement_pressed"
QT_MOC_LITERAL(43, 814, 32), // "on_buttonFrameIncrement2_pressed"
QT_MOC_LITERAL(44, 847, 33), // "on_checkBoxAutoScale_stateCha..."
QT_MOC_LITERAL(45, 881, 5), // "state"
QT_MOC_LITERAL(46, 887, 10), // "cubeFrames"
QT_MOC_LITERAL(47, 898, 9), // "cubeFrame"
QT_MOC_LITERAL(48, 908, 13) // "updateButtons"

    },
    "cubeCtrl\0cubeModeUpdated\0\0cubeFPSUpdated\0"
    "cubeFPSMultUpdated\0cubeDirUpdated\0"
    "cubeFrameUpdated\0uint32_t\0"
    "cubeFrameDeltaUpdated\0int32_t\0"
    "autoScaleUpdated\0cubeMode\0mode\0cubeFPS\0"
    "fps\0desiredFPS\0cubeFPSMult\0fm\0cubeDir\0"
    "d\0autoScale\0as\0on_lineEditFPS_editingFinished\0"
    "on_lineEditFPS_returnPressed\0"
    "on_buttonFPSD10_pressed\0on_buttonFPSD2_pressed\0"
    "on_buttonFPSX2_pressed\0on_buttonFPSX10_pressed\0"
    "on_buttonFastFastBackward_pressed\0"
    "on_buttonFastBackward_pressed\0"
    "on_buttonPlayBackward_pressed\0"
    "on_buttonStop_pressed\0"
    "on_buttonPlayForward_pressed\0"
    "on_buttonFastForward_pressed\0"
    "on_buttonFastFastForward_pressed\0"
    "on_lineEditFrame_editingFinished\0"
    "on_lineEditFrame_returnPressed\0"
    "on_scrollBarFrame_sliderMoved\0value\0"
    "on_scrollBarFrame_sliderReleased\0"
    "on_buttonFrameDecrement2_pressed\0"
    "on_buttonFrameDecrement_pressed\0"
    "on_buttonFrameIncrement_pressed\0"
    "on_buttonFrameIncrement2_pressed\0"
    "on_checkBoxAutoScale_stateChanged\0"
    "state\0cubeFrames\0cubeFrame\0updateButtons"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cubeCtrl[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  199,    2, 0x06 /* Public */,
       3,    1,  202,    2, 0x06 /* Public */,
       4,    1,  205,    2, 0x06 /* Public */,
       5,    1,  208,    2, 0x06 /* Public */,
       6,    1,  211,    2, 0x06 /* Public */,
       8,    1,  214,    2, 0x06 /* Public */,
      10,    1,  217,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,  220,    2, 0x0a /* Public */,
      13,    2,  223,    2, 0x0a /* Public */,
      16,    1,  228,    2, 0x0a /* Public */,
      18,    1,  231,    2, 0x0a /* Public */,
      20,    1,  234,    2, 0x0a /* Public */,
      22,    0,  237,    2, 0x0a /* Public */,
      23,    0,  238,    2, 0x0a /* Public */,
      24,    0,  239,    2, 0x0a /* Public */,
      25,    0,  240,    2, 0x0a /* Public */,
      26,    0,  241,    2, 0x0a /* Public */,
      27,    0,  242,    2, 0x0a /* Public */,
      28,    0,  243,    2, 0x0a /* Public */,
      29,    0,  244,    2, 0x0a /* Public */,
      30,    0,  245,    2, 0x0a /* Public */,
      31,    0,  246,    2, 0x0a /* Public */,
      32,    0,  247,    2, 0x0a /* Public */,
      33,    0,  248,    2, 0x0a /* Public */,
      34,    0,  249,    2, 0x0a /* Public */,
      35,    0,  250,    2, 0x0a /* Public */,
      36,    0,  251,    2, 0x0a /* Public */,
      37,    1,  252,    2, 0x0a /* Public */,
      39,    0,  255,    2, 0x0a /* Public */,
      40,    0,  256,    2, 0x0a /* Public */,
      41,    0,  257,    2, 0x0a /* Public */,
      42,    0,  258,    2, 0x0a /* Public */,
      43,    0,  259,    2, 0x0a /* Public */,
      44,    1,  260,    2, 0x0a /* Public */,
      46,    1,  263,    2, 0x0a /* Public */,
      47,    1,  266,    2, 0x0a /* Public */,
      48,    0,  269,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Float,    2,
    QMetaType::Void, QMetaType::Float,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,   12,
    QMetaType::Void, QMetaType::Float, QMetaType::Float,   14,   15,
    QMetaType::Void, QMetaType::Float,   17,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   38,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   45,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void,

       0        // eod
};

void cubeCtrl::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<cubeCtrl *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->cubeModeUpdated((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->cubeFPSUpdated((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 2: _t->cubeFPSMultUpdated((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 3: _t->cubeDirUpdated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->cubeFrameUpdated((*reinterpret_cast< uint32_t(*)>(_a[1]))); break;
        case 5: _t->cubeFrameDeltaUpdated((*reinterpret_cast< int32_t(*)>(_a[1]))); break;
        case 6: _t->autoScaleUpdated((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->cubeMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->cubeFPS((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 9: _t->cubeFPSMult((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 10: _t->cubeDir((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->autoScale((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->on_lineEditFPS_editingFinished(); break;
        case 13: _t->on_lineEditFPS_returnPressed(); break;
        case 14: _t->on_buttonFPSD10_pressed(); break;
        case 15: _t->on_buttonFPSD2_pressed(); break;
        case 16: _t->on_buttonFPSX2_pressed(); break;
        case 17: _t->on_buttonFPSX10_pressed(); break;
        case 18: _t->on_buttonFastFastBackward_pressed(); break;
        case 19: _t->on_buttonFastBackward_pressed(); break;
        case 20: _t->on_buttonPlayBackward_pressed(); break;
        case 21: _t->on_buttonStop_pressed(); break;
        case 22: _t->on_buttonPlayForward_pressed(); break;
        case 23: _t->on_buttonFastForward_pressed(); break;
        case 24: _t->on_buttonFastFastForward_pressed(); break;
        case 25: _t->on_lineEditFrame_editingFinished(); break;
        case 26: _t->on_lineEditFrame_returnPressed(); break;
        case 27: _t->on_scrollBarFrame_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->on_scrollBarFrame_sliderReleased(); break;
        case 29: _t->on_buttonFrameDecrement2_pressed(); break;
        case 30: _t->on_buttonFrameDecrement_pressed(); break;
        case 31: _t->on_buttonFrameIncrement_pressed(); break;
        case 32: _t->on_buttonFrameIncrement2_pressed(); break;
        case 33: _t->on_checkBoxAutoScale_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->cubeFrames((*reinterpret_cast< uint32_t(*)>(_a[1]))); break;
        case 35: _t->cubeFrame((*reinterpret_cast< uint32_t(*)>(_a[1]))); break;
        case 36: _t->updateButtons(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (cubeCtrl::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeModeUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeFPSUpdated)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeFPSMultUpdated)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeDirUpdated)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(uint32_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeFrameUpdated)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(int32_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::cubeFrameDeltaUpdated)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (cubeCtrl::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cubeCtrl::autoScaleUpdated)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject cubeCtrl::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_cubeCtrl.data,
    qt_meta_data_cubeCtrl,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *cubeCtrl::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cubeCtrl::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cubeCtrl.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int cubeCtrl::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
    return _id;
}

// SIGNAL 0
void cubeCtrl::cubeModeUpdated(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void cubeCtrl::cubeFPSUpdated(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void cubeCtrl::cubeFPSMultUpdated(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void cubeCtrl::cubeDirUpdated(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void cubeCtrl::cubeFrameUpdated(uint32_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void cubeCtrl::cubeFrameDeltaUpdated(int32_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void cubeCtrl::autoScaleUpdated(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
