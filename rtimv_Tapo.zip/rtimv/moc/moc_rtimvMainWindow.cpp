/****************************************************************************
** Meta object code from reading C++ file 'rtimvMainWindow.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../src/rtimvMainWindow.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rtimvMainWindow.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_rtimvMainWindow_t {
    QByteArrayData data[76];
    char stringdata0[1084];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_rtimvMainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_rtimvMainWindow_t qt_meta_stringdata_rtimvMainWindow = {
    {
QT_MOC_LITERAL(0, 0, 15), // "rtimvMainWindow"
QT_MOC_LITERAL(1, 16, 24), // "showToolTipCoordsChanged"
QT_MOC_LITERAL(2, 41, 0), // ""
QT_MOC_LITERAL(3, 42, 4), // "sttc"
QT_MOC_LITERAL(4, 47, 23), // "showStaticCoordsChanged"
QT_MOC_LITERAL(5, 71, 15), // "targetXcChanged"
QT_MOC_LITERAL(6, 87, 3), // "txc"
QT_MOC_LITERAL(7, 91, 15), // "targetYcChanged"
QT_MOC_LITERAL(8, 107, 3), // "tyc"
QT_MOC_LITERAL(9, 111, 20), // "targetVisibleChanged"
QT_MOC_LITERAL(10, 132, 2), // "tv"
QT_MOC_LITERAL(11, 135, 16), // "autoScaleUpdated"
QT_MOC_LITERAL(12, 152, 13), // "northAngleRaw"
QT_MOC_LITERAL(13, 166, 5), // "north"
QT_MOC_LITERAL(14, 172, 14), // "freezeRealTime"
QT_MOC_LITERAL(15, 187, 9), // "reStretch"
QT_MOC_LITERAL(16, 197, 12), // "changeCenter"
QT_MOC_LITERAL(17, 210, 11), // "resizeEvent"
QT_MOC_LITERAL(18, 222, 13), // "QResizeEvent*"
QT_MOC_LITERAL(19, 236, 17), // "showToolTipCoords"
QT_MOC_LITERAL(20, 254, 16), // "showStaticCoords"
QT_MOC_LITERAL(21, 271, 3), // "ssc"
QT_MOC_LITERAL(22, 275, 17), // "changeMouseCoords"
QT_MOC_LITERAL(23, 293, 15), // "viewLeftPressed"
QT_MOC_LITERAL(24, 309, 2), // "mp"
QT_MOC_LITERAL(25, 312, 15), // "viewLeftClicked"
QT_MOC_LITERAL(26, 328, 16), // "viewRightPressed"
QT_MOC_LITERAL(27, 345, 16), // "viewRightClicked"
QT_MOC_LITERAL(28, 362, 12), // "onWheelMoved"
QT_MOC_LITERAL(29, 375, 5), // "delta"
QT_MOC_LITERAL(30, 381, 8), // "targetXc"
QT_MOC_LITERAL(31, 390, 8), // "targetYc"
QT_MOC_LITERAL(32, 399, 13), // "targetVisible"
QT_MOC_LITERAL(33, 413, 20), // "mtxTry_colorBoxMoved"
QT_MOC_LITERAL(34, 434, 11), // "StretchBox*"
QT_MOC_LITERAL(35, 446, 2), // "sb"
QT_MOC_LITERAL(36, 449, 23), // "mtxTry_colorBoxSelected"
QT_MOC_LITERAL(37, 473, 18), // "colorBoxDeselected"
QT_MOC_LITERAL(38, 492, 14), // "colorBoxRemove"
QT_MOC_LITERAL(39, 507, 16), // "doLaunchStatsBox"
QT_MOC_LITERAL(40, 524, 14), // "doHideStatsBox"
QT_MOC_LITERAL(41, 539, 13), // "imStatsClosed"
QT_MOC_LITERAL(42, 553, 20), // "mtxTry_statsBoxMoved"
QT_MOC_LITERAL(43, 574, 23), // "mtxTry_statsBoxSelected"
QT_MOC_LITERAL(44, 598, 14), // "statsBoxRemove"
QT_MOC_LITERAL(45, 613, 13), // "addStretchBox"
QT_MOC_LITERAL(46, 627, 19), // "mtxTry_userBoxMoved"
QT_MOC_LITERAL(47, 647, 18), // "userBoxRejectMouse"
QT_MOC_LITERAL(48, 666, 13), // "userBoxRemove"
QT_MOC_LITERAL(49, 680, 2), // "sc"
QT_MOC_LITERAL(50, 683, 22), // "mtxTry_userBoxSelected"
QT_MOC_LITERAL(51, 706, 17), // "userBoxDeSelected"
QT_MOC_LITERAL(52, 724, 16), // "addStretchCircle"
QT_MOC_LITERAL(53, 741, 14), // "StretchCircle*"
QT_MOC_LITERAL(54, 756, 15), // "userCircleMoved"
QT_MOC_LITERAL(55, 772, 21), // "userCircleRejectMouse"
QT_MOC_LITERAL(56, 794, 16), // "userCircleRemove"
QT_MOC_LITERAL(57, 811, 18), // "userCircleSelected"
QT_MOC_LITERAL(58, 830, 20), // "userCircleDeSelected"
QT_MOC_LITERAL(59, 851, 14), // "addStretchLine"
QT_MOC_LITERAL(60, 866, 12), // "StretchLine*"
QT_MOC_LITERAL(61, 879, 2), // "sl"
QT_MOC_LITERAL(62, 882, 20), // "mtxTry_userLineMoved"
QT_MOC_LITERAL(63, 903, 19), // "userLineRejectMouse"
QT_MOC_LITERAL(64, 923, 14), // "userLineRemove"
QT_MOC_LITERAL(65, 938, 23), // "mtxTry_userLineSelected"
QT_MOC_LITERAL(66, 962, 18), // "userLineDeSelected"
QT_MOC_LITERAL(67, 981, 11), // "savingState"
QT_MOC_LITERAL(68, 993, 18), // "rtimv::savingState"
QT_MOC_LITERAL(69, 1012, 2), // "ss"
QT_MOC_LITERAL(70, 1015, 9), // "autoScale"
QT_MOC_LITERAL(71, 1025, 2), // "as"
QT_MOC_LITERAL(72, 1028, 18), // "borderWarningLevel"
QT_MOC_LITERAL(73, 1047, 19), // "rtimv::warningLevel"
QT_MOC_LITERAL(74, 1067, 3), // "lvl"
QT_MOC_LITERAL(75, 1071, 12) // "setBorderBox"

    },
    "rtimvMainWindow\0showToolTipCoordsChanged\0"
    "\0sttc\0showStaticCoordsChanged\0"
    "targetXcChanged\0txc\0targetYcChanged\0"
    "tyc\0targetVisibleChanged\0tv\0"
    "autoScaleUpdated\0northAngleRaw\0north\0"
    "freezeRealTime\0reStretch\0changeCenter\0"
    "resizeEvent\0QResizeEvent*\0showToolTipCoords\0"
    "showStaticCoords\0ssc\0changeMouseCoords\0"
    "viewLeftPressed\0mp\0viewLeftClicked\0"
    "viewRightPressed\0viewRightClicked\0"
    "onWheelMoved\0delta\0targetXc\0targetYc\0"
    "targetVisible\0mtxTry_colorBoxMoved\0"
    "StretchBox*\0sb\0mtxTry_colorBoxSelected\0"
    "colorBoxDeselected\0colorBoxRemove\0"
    "doLaunchStatsBox\0doHideStatsBox\0"
    "imStatsClosed\0mtxTry_statsBoxMoved\0"
    "mtxTry_statsBoxSelected\0statsBoxRemove\0"
    "addStretchBox\0mtxTry_userBoxMoved\0"
    "userBoxRejectMouse\0userBoxRemove\0sc\0"
    "mtxTry_userBoxSelected\0userBoxDeSelected\0"
    "addStretchCircle\0StretchCircle*\0"
    "userCircleMoved\0userCircleRejectMouse\0"
    "userCircleRemove\0userCircleSelected\0"
    "userCircleDeSelected\0addStretchLine\0"
    "StretchLine*\0sl\0mtxTry_userLineMoved\0"
    "userLineRejectMouse\0userLineRemove\0"
    "mtxTry_userLineSelected\0userLineDeSelected\0"
    "savingState\0rtimv::savingState\0ss\0"
    "autoScale\0as\0borderWarningLevel\0"
    "rtimv::warningLevel\0lvl\0setBorderBox"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_rtimvMainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      54,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  284,    2, 0x06 /* Public */,
       4,    1,  287,    2, 0x06 /* Public */,
       5,    1,  290,    2, 0x06 /* Public */,
       7,    1,  293,    2, 0x06 /* Public */,
       9,    1,  296,    2, 0x06 /* Public */,
      11,    1,  299,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    1,  302,    2, 0x0a /* Public */,
      14,    0,  305,    2, 0x0a /* Public */,
      15,    0,  306,    2, 0x0a /* Public */,
      16,    0,  307,    2, 0x09 /* Protected */,
      17,    1,  308,    2, 0x09 /* Protected */,
      19,    1,  311,    2, 0x0a /* Public */,
      20,    1,  314,    2, 0x0a /* Public */,
      22,    0,  317,    2, 0x0a /* Public */,
      23,    1,  318,    2, 0x0a /* Public */,
      25,    1,  321,    2, 0x0a /* Public */,
      26,    1,  324,    2, 0x0a /* Public */,
      27,    1,  327,    2, 0x0a /* Public */,
      28,    1,  330,    2, 0x0a /* Public */,
      30,    1,  333,    2, 0x0a /* Public */,
      31,    1,  336,    2, 0x0a /* Public */,
      32,    1,  339,    2, 0x0a /* Public */,
      33,    1,  342,    2, 0x0a /* Public */,
      36,    1,  345,    2, 0x0a /* Public */,
      37,    1,  348,    2, 0x0a /* Public */,
      38,    1,  351,    2, 0x0a /* Public */,
      39,    0,  354,    2, 0x0a /* Public */,
      40,    0,  355,    2, 0x0a /* Public */,
      41,    1,  356,    2, 0x0a /* Public */,
      42,    1,  359,    2, 0x0a /* Public */,
      43,    1,  362,    2, 0x0a /* Public */,
      44,    1,  365,    2, 0x0a /* Public */,
      45,    1,  368,    2, 0x0a /* Public */,
      46,    1,  371,    2, 0x0a /* Public */,
      47,    1,  374,    2, 0x0a /* Public */,
      48,    1,  377,    2, 0x0a /* Public */,
      50,    1,  380,    2, 0x0a /* Public */,
      51,    1,  383,    2, 0x0a /* Public */,
      52,    1,  386,    2, 0x0a /* Public */,
      54,    1,  389,    2, 0x0a /* Public */,
      55,    1,  392,    2, 0x0a /* Public */,
      56,    1,  395,    2, 0x0a /* Public */,
      57,    1,  398,    2, 0x0a /* Public */,
      58,    1,  401,    2, 0x0a /* Public */,
      59,    1,  404,    2, 0x0a /* Public */,
      62,    1,  407,    2, 0x0a /* Public */,
      63,    1,  410,    2, 0x0a /* Public */,
      64,    1,  413,    2, 0x0a /* Public */,
      65,    1,  416,    2, 0x0a /* Public */,
      66,    1,  419,    2, 0x0a /* Public */,
      67,    1,  422,    2, 0x0a /* Public */,
      70,    1,  425,    2, 0x0a /* Public */,
      72,    1,  428,    2, 0x0a /* Public */,
      75,    0,  431,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Float,    6,
    QMetaType::Void, QMetaType::Float,    8,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Float,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,    2,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPointF,   24,
    QMetaType::Void, QMetaType::QPointF,   24,
    QMetaType::Void, QMetaType::QPointF,   24,
    QMetaType::Void, QMetaType::QPointF,   24,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Float,    6,
    QMetaType::Void, QMetaType::Float,    8,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 34,    2,
    QMetaType::Void, 0x80000000 | 34,    2,
    QMetaType::Void, 0x80000000 | 34,    2,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void, 0x80000000 | 34,   35,
    QMetaType::Void, 0x80000000 | 34,    2,
    QMetaType::Void, 0x80000000 | 34,   49,
    QMetaType::Void, 0x80000000 | 34,   49,
    QMetaType::Void, 0x80000000 | 34,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 53,   49,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void, 0x80000000 | 68,   69,
    QMetaType::Void, QMetaType::Bool,   71,
    QMetaType::Void, 0x80000000 | 73,   74,
    QMetaType::Void,

       0        // eod
};

void rtimvMainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<rtimvMainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showToolTipCoordsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->showStaticCoordsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->targetXcChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 3: _t->targetYcChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 4: _t->targetVisibleChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->autoScaleUpdated((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->northAngleRaw((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 7: _t->freezeRealTime(); break;
        case 8: _t->reStretch(); break;
        case 9: _t->changeCenter(); break;
        case 10: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 11: _t->showToolTipCoords((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->showStaticCoords((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->changeMouseCoords(); break;
        case 14: _t->viewLeftPressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 15: _t->viewLeftClicked((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 16: _t->viewRightPressed((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 17: _t->viewRightClicked((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 18: _t->onWheelMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->targetXc((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 20: _t->targetYc((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 21: _t->targetVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->mtxTry_colorBoxMoved((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 23: _t->mtxTry_colorBoxSelected((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 24: _t->colorBoxDeselected((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 25: _t->colorBoxRemove((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 26: _t->doLaunchStatsBox(); break;
        case 27: _t->doHideStatsBox(); break;
        case 28: _t->imStatsClosed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->mtxTry_statsBoxMoved((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 30: _t->mtxTry_statsBoxSelected((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 31: _t->statsBoxRemove((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 32: _t->addStretchBox((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 33: _t->mtxTry_userBoxMoved((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 34: _t->userBoxRejectMouse((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 35: _t->userBoxRemove((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 36: _t->mtxTry_userBoxSelected((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 37: _t->userBoxDeSelected((*reinterpret_cast< StretchBox*(*)>(_a[1]))); break;
        case 38: _t->addStretchCircle((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 39: _t->userCircleMoved((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 40: _t->userCircleRejectMouse((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 41: _t->userCircleRemove((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 42: _t->userCircleSelected((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 43: _t->userCircleDeSelected((*reinterpret_cast< StretchCircle*(*)>(_a[1]))); break;
        case 44: _t->addStretchLine((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 45: _t->mtxTry_userLineMoved((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 46: _t->userLineRejectMouse((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 47: _t->userLineRemove((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 48: _t->mtxTry_userLineSelected((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 49: _t->userLineDeSelected((*reinterpret_cast< StretchLine*(*)>(_a[1]))); break;
        case 50: _t->savingState((*reinterpret_cast< rtimv::savingState(*)>(_a[1]))); break;
        case 51: _t->autoScale((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 52: _t->borderWarningLevel((*reinterpret_cast< rtimv::warningLevel(*)>(_a[1]))); break;
        case 53: _t->setBorderBox(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 23:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 25:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 29:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 30:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 31:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 32:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 33:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 34:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 35:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 36:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 37:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchBox* >(); break;
            }
            break;
        case 38:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 39:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 40:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 41:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 42:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 43:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchCircle* >(); break;
            }
            break;
        case 44:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        case 45:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        case 46:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        case 47:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        case 48:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        case 49:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StretchLine* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (rtimvMainWindow::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::showToolTipCoordsChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (rtimvMainWindow::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::showStaticCoordsChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (rtimvMainWindow::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::targetXcChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (rtimvMainWindow::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::targetYcChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (rtimvMainWindow::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::targetVisibleChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (rtimvMainWindow::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvMainWindow::autoScaleUpdated)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject rtimvMainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<rtimvBase::staticMetaObject>(),
    qt_meta_stringdata_rtimvMainWindow.data,
    qt_meta_data_rtimvMainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *rtimvMainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *rtimvMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_rtimvMainWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "application"))
        return static_cast< application*>(this);
    return rtimvBase::qt_metacast(_clname);
}

int rtimvMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = rtimvBase::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    }
    return _id;
}

// SIGNAL 0
void rtimvMainWindow::showToolTipCoordsChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void rtimvMainWindow::showStaticCoordsChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void rtimvMainWindow::targetXcChanged(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void rtimvMainWindow::targetYcChanged(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void rtimvMainWindow::targetVisibleChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void rtimvMainWindow::autoScaleUpdated(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
