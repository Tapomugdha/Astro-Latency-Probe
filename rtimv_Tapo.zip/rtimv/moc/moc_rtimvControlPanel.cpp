/****************************************************************************
** Meta object code from reading C++ file 'rtimvControlPanel.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../src/rtimvControlPanel.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rtimvControlPanel.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_rtimvControlPanel_t {
    QByteArrayData data[74];
    char stringdata0[1580];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_rtimvControlPanel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_rtimvControlPanel_t qt_meta_stringdata_rtimvControlPanel = {
    {
QT_MOC_LITERAL(0, 0, 17), // "rtimvControlPanel"
QT_MOC_LITERAL(1, 18, 14), // "launchStatsBox"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 12), // "hideStatsBox"
QT_MOC_LITERAL(4, 47, 17), // "showToolTipCoords"
QT_MOC_LITERAL(5, 65, 16), // "showStaticCoords"
QT_MOC_LITERAL(6, 82, 8), // "targetXc"
QT_MOC_LITERAL(7, 91, 3), // "txc"
QT_MOC_LITERAL(8, 95, 8), // "targetYc"
QT_MOC_LITERAL(9, 104, 3), // "tyc"
QT_MOC_LITERAL(10, 108, 13), // "targetVisible"
QT_MOC_LITERAL(11, 122, 2), // "tv"
QT_MOC_LITERAL(12, 125, 26), // "on_ZoomSlider_valueChanged"
QT_MOC_LITERAL(13, 152, 5), // "value"
QT_MOC_LITERAL(14, 158, 16), // "on_Zoom1_clicked"
QT_MOC_LITERAL(15, 175, 16), // "on_Zoom2_clicked"
QT_MOC_LITERAL(16, 192, 16), // "on_Zoom4_clicked"
QT_MOC_LITERAL(17, 209, 16), // "on_Zoom8_clicked"
QT_MOC_LITERAL(18, 226, 17), // "on_Zoom16_clicked"
QT_MOC_LITERAL(19, 244, 28), // "on_ZoomEntry_editingFinished"
QT_MOC_LITERAL(20, 273, 20), // "on_overZoom1_clicked"
QT_MOC_LITERAL(21, 294, 20), // "on_overZoom2_clicked"
QT_MOC_LITERAL(22, 315, 20), // "on_overZoom4_clicked"
QT_MOC_LITERAL(23, 336, 36), // "on_ViewViewModecheckBox_state..."
QT_MOC_LITERAL(24, 373, 18), // "enableViewViewMode"
QT_MOC_LITERAL(25, 392, 28), // "on_xcenEntry_editingFinished"
QT_MOC_LITERAL(26, 421, 28), // "on_ycenEntry_editingFinished"
QT_MOC_LITERAL(27, 450, 29), // "on_widthEntry_editingFinished"
QT_MOC_LITERAL(28, 480, 30), // "on_heightEntry_editingFinished"
QT_MOC_LITERAL(29, 511, 22), // "on_view_center_clicked"
QT_MOC_LITERAL(30, 534, 18), // "on_view_ul_clicked"
QT_MOC_LITERAL(31, 553, 18), // "on_view_up_clicked"
QT_MOC_LITERAL(32, 572, 18), // "on_view_ur_clicked"
QT_MOC_LITERAL(33, 591, 21), // "on_view_right_clicked"
QT_MOC_LITERAL(34, 613, 18), // "on_view_dr_clicked"
QT_MOC_LITERAL(35, 632, 20), // "on_view_down_clicked"
QT_MOC_LITERAL(36, 653, 18), // "on_view_dl_clicked"
QT_MOC_LITERAL(37, 672, 20), // "on_view_left_clicked"
QT_MOC_LITERAL(38, 693, 19), // "set_PointerViewMode"
QT_MOC_LITERAL(39, 713, 36), // "on_pointerViewModecomboBox_ac..."
QT_MOC_LITERAL(40, 750, 30), // "on_pointerSetLocButton_clicked"
QT_MOC_LITERAL(41, 781, 18), // "set_pointerViewCen"
QT_MOC_LITERAL(42, 800, 2), // "mp"
QT_MOC_LITERAL(43, 803, 12), // "viewBoxMoved"
QT_MOC_LITERAL(44, 816, 6), // "newcen"
QT_MOC_LITERAL(45, 823, 12), // "setScaleMode"
QT_MOC_LITERAL(46, 836, 2), // "sm"
QT_MOC_LITERAL(47, 839, 27), // "on_scaleTypeCombo_activated"
QT_MOC_LITERAL(48, 867, 26), // "on_colorbarCombo_activated"
QT_MOC_LITERAL(49, 894, 27), // "on_scaleModeCombo_activated"
QT_MOC_LITERAL(50, 922, 5), // "index"
QT_MOC_LITERAL(51, 928, 28), // "on_mindatSlider_valueChanged"
QT_MOC_LITERAL(52, 957, 30), // "on_mindatEntry_editingFinished"
QT_MOC_LITERAL(53, 988, 28), // "on_maxdatSlider_valueChanged"
QT_MOC_LITERAL(54, 1017, 30), // "on_maxdatEntry_editingFinished"
QT_MOC_LITERAL(55, 1048, 26), // "on_biasSlider_valueChanged"
QT_MOC_LITERAL(56, 1075, 28), // "on_biasEntry_editingFinished"
QT_MOC_LITERAL(57, 1104, 30), // "on_contrastSlider_valueChanged"
QT_MOC_LITERAL(58, 1135, 32), // "on_contrastEntry_editingFinished"
QT_MOC_LITERAL(59, 1168, 30), // "on_imtimerspinBox_valueChanged"
QT_MOC_LITERAL(60, 1199, 25), // "on_statsBoxButton_clicked"
QT_MOC_LITERAL(61, 1225, 24), // "showToolTipCoordsChanged"
QT_MOC_LITERAL(62, 1250, 4), // "sttc"
QT_MOC_LITERAL(63, 1255, 23), // "showStaticCoordsChanged"
QT_MOC_LITERAL(64, 1279, 30), // "on_toolTipCoordsButton_clicked"
QT_MOC_LITERAL(65, 1310, 29), // "on_staticCoordsButton_clicked"
QT_MOC_LITERAL(66, 1340, 15), // "targetXcChanged"
QT_MOC_LITERAL(67, 1356, 15), // "targetYcChanged"
QT_MOC_LITERAL(68, 1372, 20), // "targetVisibleChanged"
QT_MOC_LITERAL(69, 1393, 28), // "on_buttonTargetCross_clicked"
QT_MOC_LITERAL(70, 1422, 37), // "on_lineEditTargetPixelX_retur..."
QT_MOC_LITERAL(71, 1460, 37), // "on_lineEditTargetPixelY_retur..."
QT_MOC_LITERAL(72, 1498, 40), // "on_lineEditTargetFractionX_re..."
QT_MOC_LITERAL(73, 1539, 40) // "on_lineEditTargetFractionY_re..."

    },
    "rtimvControlPanel\0launchStatsBox\0\0"
    "hideStatsBox\0showToolTipCoords\0"
    "showStaticCoords\0targetXc\0txc\0targetYc\0"
    "tyc\0targetVisible\0tv\0on_ZoomSlider_valueChanged\0"
    "value\0on_Zoom1_clicked\0on_Zoom2_clicked\0"
    "on_Zoom4_clicked\0on_Zoom8_clicked\0"
    "on_Zoom16_clicked\0on_ZoomEntry_editingFinished\0"
    "on_overZoom1_clicked\0on_overZoom2_clicked\0"
    "on_overZoom4_clicked\0"
    "on_ViewViewModecheckBox_stateChanged\0"
    "enableViewViewMode\0on_xcenEntry_editingFinished\0"
    "on_ycenEntry_editingFinished\0"
    "on_widthEntry_editingFinished\0"
    "on_heightEntry_editingFinished\0"
    "on_view_center_clicked\0on_view_ul_clicked\0"
    "on_view_up_clicked\0on_view_ur_clicked\0"
    "on_view_right_clicked\0on_view_dr_clicked\0"
    "on_view_down_clicked\0on_view_dl_clicked\0"
    "on_view_left_clicked\0set_PointerViewMode\0"
    "on_pointerViewModecomboBox_activated\0"
    "on_pointerSetLocButton_clicked\0"
    "set_pointerViewCen\0mp\0viewBoxMoved\0"
    "newcen\0setScaleMode\0sm\0"
    "on_scaleTypeCombo_activated\0"
    "on_colorbarCombo_activated\0"
    "on_scaleModeCombo_activated\0index\0"
    "on_mindatSlider_valueChanged\0"
    "on_mindatEntry_editingFinished\0"
    "on_maxdatSlider_valueChanged\0"
    "on_maxdatEntry_editingFinished\0"
    "on_biasSlider_valueChanged\0"
    "on_biasEntry_editingFinished\0"
    "on_contrastSlider_valueChanged\0"
    "on_contrastEntry_editingFinished\0"
    "on_imtimerspinBox_valueChanged\0"
    "on_statsBoxButton_clicked\0"
    "showToolTipCoordsChanged\0sttc\0"
    "showStaticCoordsChanged\0"
    "on_toolTipCoordsButton_clicked\0"
    "on_staticCoordsButton_clicked\0"
    "targetXcChanged\0targetYcChanged\0"
    "targetVisibleChanged\0on_buttonTargetCross_clicked\0"
    "on_lineEditTargetPixelX_returnPressed\0"
    "on_lineEditTargetPixelY_returnPressed\0"
    "on_lineEditTargetFractionX_returnPressed\0"
    "on_lineEditTargetFractionY_returnPressed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_rtimvControlPanel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      63,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  329,    2, 0x06 /* Public */,
       3,    0,  330,    2, 0x06 /* Public */,
       4,    1,  331,    2, 0x06 /* Public */,
       5,    1,  334,    2, 0x06 /* Public */,
       6,    1,  337,    2, 0x06 /* Public */,
       8,    1,  340,    2, 0x06 /* Public */,
      10,    1,  343,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    1,  346,    2, 0x09 /* Protected */,
      14,    0,  349,    2, 0x09 /* Protected */,
      15,    0,  350,    2, 0x09 /* Protected */,
      16,    0,  351,    2, 0x09 /* Protected */,
      17,    0,  352,    2, 0x09 /* Protected */,
      18,    0,  353,    2, 0x09 /* Protected */,
      19,    0,  354,    2, 0x09 /* Protected */,
      20,    0,  355,    2, 0x09 /* Protected */,
      21,    0,  356,    2, 0x09 /* Protected */,
      22,    0,  357,    2, 0x09 /* Protected */,
      23,    1,  358,    2, 0x09 /* Protected */,
      24,    1,  361,    2, 0x09 /* Protected */,
      25,    0,  364,    2, 0x09 /* Protected */,
      26,    0,  365,    2, 0x09 /* Protected */,
      27,    0,  366,    2, 0x09 /* Protected */,
      28,    0,  367,    2, 0x09 /* Protected */,
      29,    0,  368,    2, 0x09 /* Protected */,
      30,    0,  369,    2, 0x09 /* Protected */,
      31,    0,  370,    2, 0x09 /* Protected */,
      32,    0,  371,    2, 0x09 /* Protected */,
      33,    0,  372,    2, 0x09 /* Protected */,
      34,    0,  373,    2, 0x09 /* Protected */,
      35,    0,  374,    2, 0x09 /* Protected */,
      36,    0,  375,    2, 0x09 /* Protected */,
      37,    0,  376,    2, 0x09 /* Protected */,
      38,    1,  377,    2, 0x0a /* Public */,
      39,    1,  380,    2, 0x0a /* Public */,
      40,    0,  383,    2, 0x0a /* Public */,
      41,    1,  384,    2, 0x0a /* Public */,
      43,    1,  387,    2, 0x0a /* Public */,
      45,    1,  390,    2, 0x0a /* Public */,
      47,    1,  393,    2, 0x09 /* Protected */,
      48,    1,  396,    2, 0x09 /* Protected */,
      49,    1,  399,    2, 0x0a /* Public */,
      51,    1,  402,    2, 0x0a /* Public */,
      52,    0,  405,    2, 0x0a /* Public */,
      53,    1,  406,    2, 0x0a /* Public */,
      54,    0,  409,    2, 0x0a /* Public */,
      55,    1,  410,    2, 0x0a /* Public */,
      56,    0,  413,    2, 0x0a /* Public */,
      57,    1,  414,    2, 0x0a /* Public */,
      58,    0,  417,    2, 0x0a /* Public */,
      59,    1,  418,    2, 0x0a /* Public */,
      60,    0,  421,    2, 0x0a /* Public */,
      61,    1,  422,    2, 0x0a /* Public */,
      63,    1,  425,    2, 0x0a /* Public */,
      64,    0,  428,    2, 0x0a /* Public */,
      65,    0,  429,    2, 0x0a /* Public */,
      66,    1,  430,    2, 0x0a /* Public */,
      67,    1,  433,    2, 0x0a /* Public */,
      68,    1,  436,    2, 0x0a /* Public */,
      69,    0,  439,    2, 0x0a /* Public */,
      70,    0,  440,    2, 0x0a /* Public */,
      71,    0,  441,    2, 0x0a /* Public */,
      72,    0,  442,    2, 0x0a /* Public */,
      73,    0,  443,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Float,    7,
    QMetaType::Void, QMetaType::Float,    9,
    QMetaType::Void, QMetaType::Bool,   11,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPointF,   42,
    QMetaType::Void, QMetaType::QRectF,   44,
    QMetaType::Void, QMetaType::Int,   46,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,   50,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   62,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Float,    7,
    QMetaType::Void, QMetaType::Float,    9,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void rtimvControlPanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<rtimvControlPanel *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->launchStatsBox(); break;
        case 1: _t->hideStatsBox(); break;
        case 2: _t->showToolTipCoords((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->showStaticCoords((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->targetXc((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 5: _t->targetYc((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 6: _t->targetVisible((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->on_ZoomSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_Zoom1_clicked(); break;
        case 9: _t->on_Zoom2_clicked(); break;
        case 10: _t->on_Zoom4_clicked(); break;
        case 11: _t->on_Zoom8_clicked(); break;
        case 12: _t->on_Zoom16_clicked(); break;
        case 13: _t->on_ZoomEntry_editingFinished(); break;
        case 14: _t->on_overZoom1_clicked(); break;
        case 15: _t->on_overZoom2_clicked(); break;
        case 16: _t->on_overZoom4_clicked(); break;
        case 17: _t->on_ViewViewModecheckBox_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->enableViewViewMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_xcenEntry_editingFinished(); break;
        case 20: _t->on_ycenEntry_editingFinished(); break;
        case 21: _t->on_widthEntry_editingFinished(); break;
        case 22: _t->on_heightEntry_editingFinished(); break;
        case 23: _t->on_view_center_clicked(); break;
        case 24: _t->on_view_ul_clicked(); break;
        case 25: _t->on_view_up_clicked(); break;
        case 26: _t->on_view_ur_clicked(); break;
        case 27: _t->on_view_right_clicked(); break;
        case 28: _t->on_view_dr_clicked(); break;
        case 29: _t->on_view_down_clicked(); break;
        case 30: _t->on_view_dl_clicked(); break;
        case 31: _t->on_view_left_clicked(); break;
        case 32: _t->set_PointerViewMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->on_pointerViewModecomboBox_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->on_pointerSetLocButton_clicked(); break;
        case 35: _t->set_pointerViewCen((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 36: _t->viewBoxMoved((*reinterpret_cast< const QRectF(*)>(_a[1]))); break;
        case 37: _t->setScaleMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->on_scaleTypeCombo_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->on_colorbarCombo_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->on_scaleModeCombo_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->on_mindatSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->on_mindatEntry_editingFinished(); break;
        case 43: _t->on_maxdatSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->on_maxdatEntry_editingFinished(); break;
        case 45: _t->on_biasSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 46: _t->on_biasEntry_editingFinished(); break;
        case 47: _t->on_contrastSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 48: _t->on_contrastEntry_editingFinished(); break;
        case 49: _t->on_imtimerspinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 50: _t->on_statsBoxButton_clicked(); break;
        case 51: _t->showToolTipCoordsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 52: _t->showStaticCoordsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 53: _t->on_toolTipCoordsButton_clicked(); break;
        case 54: _t->on_staticCoordsButton_clicked(); break;
        case 55: _t->targetXcChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 56: _t->targetYcChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 57: _t->targetVisibleChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 58: _t->on_buttonTargetCross_clicked(); break;
        case 59: _t->on_lineEditTargetPixelX_returnPressed(); break;
        case 60: _t->on_lineEditTargetPixelY_returnPressed(); break;
        case 61: _t->on_lineEditTargetFractionX_returnPressed(); break;
        case 62: _t->on_lineEditTargetFractionY_returnPressed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (rtimvControlPanel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::launchStatsBox)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::hideStatsBox)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::showToolTipCoords)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::showStaticCoords)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::targetXc)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::targetYc)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (rtimvControlPanel::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&rtimvControlPanel::targetVisible)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject rtimvControlPanel::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_rtimvControlPanel.data,
    qt_meta_data_rtimvControlPanel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *rtimvControlPanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *rtimvControlPanel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_rtimvControlPanel.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int rtimvControlPanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 63)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 63;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 63)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 63;
    }
    return _id;
}

// SIGNAL 0
void rtimvControlPanel::launchStatsBox()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void rtimvControlPanel::hideStatsBox()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void rtimvControlPanel::showToolTipCoords(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void rtimvControlPanel::showStaticCoords(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void rtimvControlPanel::targetXc(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void rtimvControlPanel::targetYc(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void rtimvControlPanel::targetVisible(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
