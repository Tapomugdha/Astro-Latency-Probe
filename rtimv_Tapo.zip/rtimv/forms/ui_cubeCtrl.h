/********************************************************************************
** Form generated from reading UI file 'cubeCtrl.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUBECTRL_H
#define UI_CUBECTRL_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cubeCtrl
{
public:
    QGridLayout *gridLayout_2;
    QHBoxLayout *hlayoutTop;
    QVBoxLayout *vlayoutPlayback;
    QHBoxLayout *hlayoutPlayback;
    QSpacerItem *horizontalSpacer_5;
    QLabel *labelPlayback;
    QLineEdit *lineEditFPS;
    QLabel *labelFPS;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *hlayoutFPSMult;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *buttonFPSD10;
    QPushButton *buttonFPSD2;
    QPushButton *buttonFPSX2;
    QPushButton *buttonFPSX10;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *hlayoutPlayButtons;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *buttonFastFastBackward;
    QPushButton *buttonFastBackward;
    QPushButton *buttonPlayBackward;
    QPushButton *buttonStop;
    QPushButton *buttonPlayForward;
    QPushButton *buttonFastForward;
    QPushButton *buttonFastFastForward;
    QSpacerItem *horizontalSpacer_10;
    QVBoxLayout *vlayoutFrame;
    QHBoxLayout *hlayoutFrame;
    QSpacerItem *horizontalSpacer;
    QLabel *labelFrame;
    QLineEdit *lineEditFrame;
    QLabel *labelFrames;
    QSpacerItem *horizontalSpacer_2;
    QScrollBar *scrollBarFrame;
    QHBoxLayout *hlayoutFramAdvance;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *buttonFrameDecrement2;
    QPushButton *buttonFrameDecrement;
    QPushButton *buttonFrameIncrement;
    QPushButton *buttonFrameIncrement2;
    QSpacerItem *horizontalSpacer_4;
    QGridLayout *gridLayout;
    QPushButton *buttonRestretch;
    QSpacerItem *horizontalSpacer_11;
    QCheckBox *checkBoxAutoScale;
    QCheckBox *checkBox;
    QSpacerItem *horizontalSpacer_12;

    void setupUi(QWidget *cubeCtrl)
    {
        if (cubeCtrl->objectName().isEmpty())
            cubeCtrl->setObjectName(QString::fromUtf8("cubeCtrl"));
        cubeCtrl->resize(1358, 249);
        gridLayout_2 = new QGridLayout(cubeCtrl);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        hlayoutTop = new QHBoxLayout();
        hlayoutTop->setObjectName(QString::fromUtf8("hlayoutTop"));
        vlayoutPlayback = new QVBoxLayout();
        vlayoutPlayback->setObjectName(QString::fromUtf8("vlayoutPlayback"));
        hlayoutPlayback = new QHBoxLayout();
        hlayoutPlayback->setObjectName(QString::fromUtf8("hlayoutPlayback"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutPlayback->addItem(horizontalSpacer_5);

        labelPlayback = new QLabel(cubeCtrl);
        labelPlayback->setObjectName(QString::fromUtf8("labelPlayback"));
        labelPlayback->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        hlayoutPlayback->addWidget(labelPlayback);

        lineEditFPS = new QLineEdit(cubeCtrl);
        lineEditFPS->setObjectName(QString::fromUtf8("lineEditFPS"));
        lineEditFPS->setFocusPolicy(Qt::StrongFocus);

        hlayoutPlayback->addWidget(lineEditFPS);

        labelFPS = new QLabel(cubeCtrl);
        labelFPS->setObjectName(QString::fromUtf8("labelFPS"));

        hlayoutPlayback->addWidget(labelFPS);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutPlayback->addItem(horizontalSpacer_6);

        hlayoutPlayback->setStretch(0, 2);
        hlayoutPlayback->setStretch(1, 2);
        hlayoutPlayback->setStretch(2, 2);
        hlayoutPlayback->setStretch(3, 4);
        hlayoutPlayback->setStretch(4, 2);

        vlayoutPlayback->addLayout(hlayoutPlayback);

        hlayoutFPSMult = new QHBoxLayout();
        hlayoutFPSMult->setObjectName(QString::fromUtf8("hlayoutFPSMult"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFPSMult->addItem(horizontalSpacer_7);

        buttonFPSD10 = new QPushButton(cubeCtrl);
        buttonFPSD10->setObjectName(QString::fromUtf8("buttonFPSD10"));
        buttonFPSD10->setFocusPolicy(Qt::NoFocus);

        hlayoutFPSMult->addWidget(buttonFPSD10);

        buttonFPSD2 = new QPushButton(cubeCtrl);
        buttonFPSD2->setObjectName(QString::fromUtf8("buttonFPSD2"));
        buttonFPSD2->setFocusPolicy(Qt::NoFocus);

        hlayoutFPSMult->addWidget(buttonFPSD2);

        buttonFPSX2 = new QPushButton(cubeCtrl);
        buttonFPSX2->setObjectName(QString::fromUtf8("buttonFPSX2"));
        buttonFPSX2->setFocusPolicy(Qt::NoFocus);

        hlayoutFPSMult->addWidget(buttonFPSX2);

        buttonFPSX10 = new QPushButton(cubeCtrl);
        buttonFPSX10->setObjectName(QString::fromUtf8("buttonFPSX10"));
        buttonFPSX10->setFocusPolicy(Qt::NoFocus);

        hlayoutFPSMult->addWidget(buttonFPSX10);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFPSMult->addItem(horizontalSpacer_8);


        vlayoutPlayback->addLayout(hlayoutFPSMult);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        vlayoutPlayback->addItem(verticalSpacer);

        hlayoutPlayButtons = new QHBoxLayout();
        hlayoutPlayButtons->setObjectName(QString::fromUtf8("hlayoutPlayButtons"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutPlayButtons->addItem(horizontalSpacer_9);

        buttonFastFastBackward = new QPushButton(cubeCtrl);
        buttonFastFastBackward->setObjectName(QString::fromUtf8("buttonFastFastBackward"));
        buttonFastFastBackward->setFocusPolicy(Qt::NoFocus);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/step-backward-2.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/icons/step-backward-2.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonFastFastBackward->setIcon(icon);
        buttonFastFastBackward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonFastFastBackward);

        buttonFastBackward = new QPushButton(cubeCtrl);
        buttonFastBackward->setObjectName(QString::fromUtf8("buttonFastBackward"));
        buttonFastBackward->setFocusPolicy(Qt::NoFocus);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/step-backward.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon1.addFile(QString::fromUtf8(":/icons/step-backward.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonFastBackward->setIcon(icon1);
        buttonFastBackward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonFastBackward);

        buttonPlayBackward = new QPushButton(cubeCtrl);
        buttonPlayBackward->setObjectName(QString::fromUtf8("buttonPlayBackward"));
        buttonPlayBackward->setFocusPolicy(Qt::NoFocus);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/play-reverse-48.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon2.addFile(QString::fromUtf8(":/icons/play-reverse-48.png"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonPlayBackward->setIcon(icon2);
        buttonPlayBackward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonPlayBackward);

        buttonStop = new QPushButton(cubeCtrl);
        buttonStop->setObjectName(QString::fromUtf8("buttonStop"));
        buttonStop->setFocusPolicy(Qt::NoFocus);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/stop.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon3.addFile(QString::fromUtf8(":/icons/stop.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonStop->setIcon(icon3);
        buttonStop->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonStop);

        buttonPlayForward = new QPushButton(cubeCtrl);
        buttonPlayForward->setObjectName(QString::fromUtf8("buttonPlayForward"));
        buttonPlayForward->setFocusPolicy(Qt::NoFocus);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/icons/play.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon4.addFile(QString::fromUtf8(":/icons/play.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonPlayForward->setIcon(icon4);
        buttonPlayForward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonPlayForward);

        buttonFastForward = new QPushButton(cubeCtrl);
        buttonFastForward->setObjectName(QString::fromUtf8("buttonFastForward"));
        buttonFastForward->setFocusPolicy(Qt::NoFocus);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/icons/step-forward.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon5.addFile(QString::fromUtf8(":/icons/step-forward.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonFastForward->setIcon(icon5);
        buttonFastForward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonFastForward);

        buttonFastFastForward = new QPushButton(cubeCtrl);
        buttonFastFastForward->setObjectName(QString::fromUtf8("buttonFastFastForward"));
        buttonFastFastForward->setFocusPolicy(Qt::NoFocus);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/icons/step-forward-2.svg"), QSize(), QIcon::Normal, QIcon::Off);
        icon6.addFile(QString::fromUtf8(":/icons/step-forward-2.svg"), QSize(), QIcon::Disabled, QIcon::Off);
        buttonFastFastForward->setIcon(icon6);
        buttonFastFastForward->setIconSize(QSize(48, 48));

        hlayoutPlayButtons->addWidget(buttonFastFastForward);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutPlayButtons->addItem(horizontalSpacer_10);


        vlayoutPlayback->addLayout(hlayoutPlayButtons);

        vlayoutPlayback->setStretch(0, 4);
        vlayoutPlayback->setStretch(1, 4);
        vlayoutPlayback->setStretch(2, 1);
        vlayoutPlayback->setStretch(3, 4);

        hlayoutTop->addLayout(vlayoutPlayback);

        vlayoutFrame = new QVBoxLayout();
        vlayoutFrame->setObjectName(QString::fromUtf8("vlayoutFrame"));
        hlayoutFrame = new QHBoxLayout();
        hlayoutFrame->setObjectName(QString::fromUtf8("hlayoutFrame"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFrame->addItem(horizontalSpacer);

        labelFrame = new QLabel(cubeCtrl);
        labelFrame->setObjectName(QString::fromUtf8("labelFrame"));
        labelFrame->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        hlayoutFrame->addWidget(labelFrame);

        lineEditFrame = new QLineEdit(cubeCtrl);
        lineEditFrame->setObjectName(QString::fromUtf8("lineEditFrame"));
        lineEditFrame->setFocusPolicy(Qt::StrongFocus);
        lineEditFrame->setAlignment(Qt::AlignCenter);

        hlayoutFrame->addWidget(lineEditFrame);

        labelFrames = new QLabel(cubeCtrl);
        labelFrames->setObjectName(QString::fromUtf8("labelFrames"));

        hlayoutFrame->addWidget(labelFrames);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFrame->addItem(horizontalSpacer_2);

        hlayoutFrame->setStretch(0, 5);
        hlayoutFrame->setStretch(1, 2);
        hlayoutFrame->setStretch(2, 4);
        hlayoutFrame->setStretch(3, 4);
        hlayoutFrame->setStretch(4, 5);

        vlayoutFrame->addLayout(hlayoutFrame);

        scrollBarFrame = new QScrollBar(cubeCtrl);
        scrollBarFrame->setObjectName(QString::fromUtf8("scrollBarFrame"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scrollBarFrame->sizePolicy().hasHeightForWidth());
        scrollBarFrame->setSizePolicy(sizePolicy);
        scrollBarFrame->setPageStep(1);
        scrollBarFrame->setOrientation(Qt::Horizontal);

        vlayoutFrame->addWidget(scrollBarFrame);

        hlayoutFramAdvance = new QHBoxLayout();
        hlayoutFramAdvance->setObjectName(QString::fromUtf8("hlayoutFramAdvance"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFramAdvance->addItem(horizontalSpacer_3);

        buttonFrameDecrement2 = new QPushButton(cubeCtrl);
        buttonFrameDecrement2->setObjectName(QString::fromUtf8("buttonFrameDecrement2"));
        buttonFrameDecrement2->setFocusPolicy(Qt::NoFocus);
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/icons/skip-backward.svg"), QSize(), QIcon::Normal, QIcon::Off);
        buttonFrameDecrement2->setIcon(icon7);
        buttonFrameDecrement2->setIconSize(QSize(48, 48));

        hlayoutFramAdvance->addWidget(buttonFrameDecrement2);

        buttonFrameDecrement = new QPushButton(cubeCtrl);
        buttonFrameDecrement->setObjectName(QString::fromUtf8("buttonFrameDecrement"));
        buttonFrameDecrement->setFocusPolicy(Qt::NoFocus);
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/icons/skip-previous.svg"), QSize(), QIcon::Normal, QIcon::Off);
        buttonFrameDecrement->setIcon(icon8);
        buttonFrameDecrement->setIconSize(QSize(48, 48));

        hlayoutFramAdvance->addWidget(buttonFrameDecrement);

        buttonFrameIncrement = new QPushButton(cubeCtrl);
        buttonFrameIncrement->setObjectName(QString::fromUtf8("buttonFrameIncrement"));
        buttonFrameIncrement->setFocusPolicy(Qt::NoFocus);
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/icons/skip-next.svg"), QSize(), QIcon::Normal, QIcon::Off);
        buttonFrameIncrement->setIcon(icon9);
        buttonFrameIncrement->setIconSize(QSize(48, 48));

        hlayoutFramAdvance->addWidget(buttonFrameIncrement);

        buttonFrameIncrement2 = new QPushButton(cubeCtrl);
        buttonFrameIncrement2->setObjectName(QString::fromUtf8("buttonFrameIncrement2"));
        buttonFrameIncrement2->setFocusPolicy(Qt::NoFocus);
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/icons/skip-forward.svg"), QSize(), QIcon::Normal, QIcon::Off);
        buttonFrameIncrement2->setIcon(icon10);
        buttonFrameIncrement2->setIconSize(QSize(48, 48));

        hlayoutFramAdvance->addWidget(buttonFrameIncrement2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlayoutFramAdvance->addItem(horizontalSpacer_4);


        vlayoutFrame->addLayout(hlayoutFramAdvance);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        buttonRestretch = new QPushButton(cubeCtrl);
        buttonRestretch->setObjectName(QString::fromUtf8("buttonRestretch"));
        buttonRestretch->setFocusPolicy(Qt::NoFocus);
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/icons/refresh.svg"), QSize(), QIcon::Normal, QIcon::Off);
        buttonRestretch->setIcon(icon11);
        buttonRestretch->setIconSize(QSize(48, 48));

        gridLayout->addWidget(buttonRestretch, 0, 3, 1, 1);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_11, 0, 4, 1, 1);

        checkBoxAutoScale = new QCheckBox(cubeCtrl);
        checkBoxAutoScale->setObjectName(QString::fromUtf8("checkBoxAutoScale"));
        checkBoxAutoScale->setFocusPolicy(Qt::NoFocus);

        gridLayout->addWidget(checkBoxAutoScale, 0, 2, 1, 1);

        checkBox = new QCheckBox(cubeCtrl);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setEnabled(false);
        checkBox->setFocusPolicy(Qt::NoFocus);

        gridLayout->addWidget(checkBox, 0, 1, 1, 1);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_12, 0, 0, 1, 1);


        vlayoutFrame->addLayout(gridLayout);

        vlayoutFrame->setStretch(0, 4);
        vlayoutFrame->setStretch(1, 1);
        vlayoutFrame->setStretch(2, 4);
        vlayoutFrame->setStretch(3, 4);

        hlayoutTop->addLayout(vlayoutFrame);

        hlayoutTop->setStretch(0, 1);
        hlayoutTop->setStretch(1, 1);

        gridLayout_2->addLayout(hlayoutTop, 0, 0, 1, 1);


        retranslateUi(cubeCtrl);

        QMetaObject::connectSlotsByName(cubeCtrl);
    } // setupUi

    void retranslateUi(QWidget *cubeCtrl)
    {
        cubeCtrl->setWindowTitle(QCoreApplication::translate("cubeCtrl", "Form", nullptr));
        labelPlayback->setText(QCoreApplication::translate("cubeCtrl", "Playback:", nullptr));
        labelFPS->setText(QCoreApplication::translate("cubeCtrl", "fps", nullptr));
#if QT_CONFIG(tooltip)
        buttonFPSD10->setToolTip(QCoreApplication::translate("cubeCtrl", "fps /10", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFPSD10->setText(QCoreApplication::translate("cubeCtrl", "/10", nullptr));
#if QT_CONFIG(tooltip)
        buttonFPSD2->setToolTip(QCoreApplication::translate("cubeCtrl", "fps /2", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFPSD2->setText(QCoreApplication::translate("cubeCtrl", "/2", nullptr));
#if QT_CONFIG(tooltip)
        buttonFPSX2->setToolTip(QCoreApplication::translate("cubeCtrl", "fps x2", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFPSX2->setText(QCoreApplication::translate("cubeCtrl", "x2", nullptr));
#if QT_CONFIG(tooltip)
        buttonFPSX10->setToolTip(QCoreApplication::translate("cubeCtrl", "fps x10", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFPSX10->setText(QCoreApplication::translate("cubeCtrl", "x10", nullptr));
#if QT_CONFIG(tooltip)
        buttonFastFastBackward->setToolTip(QCoreApplication::translate("cubeCtrl", "reverse x10", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFastFastBackward->setText(QString());
#if QT_CONFIG(tooltip)
        buttonFastBackward->setToolTip(QCoreApplication::translate("cubeCtrl", "reverse x2", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFastBackward->setText(QString());
#if QT_CONFIG(tooltip)
        buttonPlayBackward->setToolTip(QCoreApplication::translate("cubeCtrl", "reverse x1", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonPlayBackward->setText(QString());
#if QT_CONFIG(tooltip)
        buttonStop->setToolTip(QCoreApplication::translate("cubeCtrl", "stop", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonStop->setText(QString());
#if QT_CONFIG(tooltip)
        buttonPlayForward->setToolTip(QCoreApplication::translate("cubeCtrl", "play x1", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonPlayForward->setText(QString());
#if QT_CONFIG(tooltip)
        buttonFastForward->setToolTip(QCoreApplication::translate("cubeCtrl", "play x2", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFastForward->setText(QString());
#if QT_CONFIG(tooltip)
        buttonFastFastForward->setToolTip(QCoreApplication::translate("cubeCtrl", "play x10", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFastFastForward->setText(QString());
        labelFrame->setText(QCoreApplication::translate("cubeCtrl", "Frame", nullptr));
        labelFrames->setText(QCoreApplication::translate("cubeCtrl", "NNNN", nullptr));
#if QT_CONFIG(tooltip)
        buttonFrameDecrement2->setToolTip(QCoreApplication::translate("cubeCtrl", "-10 frames", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFrameDecrement2->setText(QString());
#if QT_CONFIG(shortcut)
        buttonFrameDecrement2->setShortcut(QString());
#endif // QT_CONFIG(shortcut)
#if QT_CONFIG(tooltip)
        buttonFrameDecrement->setToolTip(QCoreApplication::translate("cubeCtrl", "-1 frame", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFrameDecrement->setText(QString());
#if QT_CONFIG(tooltip)
        buttonFrameIncrement->setToolTip(QCoreApplication::translate("cubeCtrl", "+1 frame", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFrameIncrement->setText(QString());
#if QT_CONFIG(tooltip)
        buttonFrameIncrement2->setToolTip(QCoreApplication::translate("cubeCtrl", "+10 frames", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonFrameIncrement2->setText(QString());
        buttonRestretch->setText(QString());
        checkBoxAutoScale->setText(QCoreApplication::translate("cubeCtrl", "Auto Scale", nullptr));
        checkBox->setText(QCoreApplication::translate("cubeCtrl", "Global Scale", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cubeCtrl: public Ui_cubeCtrl {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUBECTRL_H
