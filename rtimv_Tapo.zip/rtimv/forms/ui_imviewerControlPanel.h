/********************************************************************************
** Form generated from reading UI file 'imviewerControlPanel.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMVIEWERCONTROLPANEL_H
#define UI_IMVIEWERCONTROLPANEL_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_imviewerControlPanel
{
public:
    QTabWidget *tabWidget;
    QWidget *tabView;
    QLabel *TextPixelVal;
    QLabel *label_10;
    QPushButton *Zoom4;
    QLabel *label_4;
    QLineEdit *ycenEntry;
    QLabel *TextCoordX;
    QLabel *label_12;
    QPushButton *view_left;
    QLineEdit *widthEntry;
    QLabel *label_11;
    QPushButton *view_ur;
    QPushButton *view_dr;
    QLineEdit *ZoomEntry;
    QGraphicsView *pointerView;
    QPushButton *view_center;
    QLabel *TextPixelValLabel;
    QLineEdit *heightEntry;
    QPushButton *Zoom8;
    QPushButton *view_right;
    QPushButton *view_down;
    QLabel *TextCoordY;
    QPushButton *Zoom2;
    QPushButton *view_ul;
    QSlider *ZoomSlider;
    QLabel *label_9;
    QLabel *TextCoordXLabel;
    QPushButton *Zoom16;
    QLabel *TextCoordYLabel;
    QPushButton *view_dl;
    QLineEdit *xcenEntry;
    QPushButton *Zoom1;
    QPushButton *view_up;
    QGraphicsView *viewView;
    QPushButton *pointerSetLocButton;
    QPushButton *overZoom4;
    QPushButton *overZoom2;
    QPushButton *overZoom1;
    QLabel *label_5;
    QWidget *tabColor;
    QLabel *maxdatLabel;
    QSlider *mindatSlider;
    QLineEdit *mindatEntry;
    QLabel *mindatLabel;
    QSlider *maxdatSlider;
    QLineEdit *maxdatEntry;
    QSlider *biasSlider;
    QLineEdit *biasEntry;
    QLabel *biasLabel;
    QSlider *contrastSlider;
    QLineEdit *contrastEntry;
    QLabel *constrastLabel;
    QComboBox *scaleModeCombo;
    QComboBox *scaleTypeCombo;
    QComboBox *colorbarCombo;
    QLabel *scalemodeLabel;
    QLabel *scaletypeLabel;
    QLabel *colorbarlabel;
    QLineEdit *mindatRelEntry;
    QLineEdit *maxdatRelEntry;
    QLineEdit *biasRelEntry;
    QLineEdit *contrastRelEntry;
    QPushButton *absfixedButton;
    QPushButton *relfixedButton;
    QWidget *tabSetup;
    QCheckBox *ViewViewModecheckBox;
    QComboBox *pointerViewModecomboBox;
    QLabel *label;
    QSpinBox *imtimerspinBox;
    QLabel *label_2;
    QPushButton *statsBoxButton;
    QPushButton *toolTipCoordsButton;
    QPushButton *staticCoordsButton;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *vLayoutTargetCross;
    QHBoxLayout *hlTargetCross;
    QSpacerItem *horizontalSpacer;
    QLabel *labelTargetCross;
    QPushButton *buttonTargetCross;
    QGridLayout *gLayoutTargetCross;
    QLineEdit *lineEditTargetFractionY;
    QLineEdit *lineEditTargetPixelX;
    QLabel *labelPixel;
    QLabel *labelFraction;
    QLineEdit *lineEditTargetFractionX;
    QLabel *labelTargetY;
    QLabel *labelTargetX;
    QLineEdit *lineEditTargetPixelY;

    void setupUi(QWidget *imviewerControlPanel)
    {
        if (imviewerControlPanel->objectName().isEmpty())
            imviewerControlPanel->setObjectName(QString::fromUtf8("imviewerControlPanel"));
        imviewerControlPanel->resize(723, 367);
        tabWidget = new QTabWidget(imviewerControlPanel);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 721, 361));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        tabWidget->setFont(font);
        tabWidget->setUsesScrollButtons(false);
        tabView = new QWidget();
        tabView->setObjectName(QString::fromUtf8("tabView"));
        TextPixelVal = new QLabel(tabView);
        TextPixelVal->setObjectName(QString::fromUtf8("TextPixelVal"));
        TextPixelVal->setGeometry(QRect(540, 268, 80, 20));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        TextPixelVal->setPalette(palette);
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setWeight(50);
        TextPixelVal->setFont(font1);
        TextPixelVal->setFrameShape(QFrame::Box);
        TextPixelVal->setAlignment(Qt::AlignCenter);
        TextPixelVal->setTextInteractionFlags(Qt::NoTextInteraction);
        label_10 = new QLabel(tabView);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(0, 300, 51, 25));
        label_10->setFont(font);
        label_10->setAlignment(Qt::AlignCenter);
        Zoom4 = new QPushButton(tabView);
        Zoom4->setObjectName(QString::fromUtf8("Zoom4"));
        Zoom4->setGeometry(QRect(250, 104, 61, 24));
        Zoom4->setFont(font1);
        label_4 = new QLabel(tabView);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(250, 10, 51, 20));
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);
        ycenEntry = new QLineEdit(tabView);
        ycenEntry->setObjectName(QString::fromUtf8("ycenEntry"));
        ycenEntry->setGeometry(QRect(50, 300, 81, 25));
        ycenEntry->setFont(font1);
        ycenEntry->setAlignment(Qt::AlignCenter);
        TextCoordX = new QLabel(tabView);
        TextCoordX->setObjectName(QString::fromUtf8("TextCoordX"));
        TextCoordX->setGeometry(QRect(420, 268, 80, 20));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Button, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush);
        TextCoordX->setPalette(palette1);
        TextCoordX->setFont(font1);
        TextCoordX->setFrameShape(QFrame::Box);
        TextCoordX->setAlignment(Qt::AlignCenter);
        TextCoordX->setTextInteractionFlags(Qt::NoTextInteraction);
        label_12 = new QLabel(tabView);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(130, 300, 21, 25));
        label_12->setFont(font);
        label_12->setAlignment(Qt::AlignCenter);
        view_left = new QPushButton(tabView);
        view_left->setObjectName(QString::fromUtf8("view_left"));
        view_left->setGeometry(QRect(250, 270, 24, 24));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/arrow_left_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_left->setIcon(icon);
        view_left->setIconSize(QSize(1624, 24));
        widthEntry = new QLineEdit(tabView);
        widthEntry->setObjectName(QString::fromUtf8("widthEntry"));
        widthEntry->setGeometry(QRect(150, 270, 81, 25));
        widthEntry->setFont(font1);
        widthEntry->setAlignment(Qt::AlignCenter);
        label_11 = new QLabel(tabView);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(0, 270, 51, 25));
        label_11->setFont(font);
        label_11->setAlignment(Qt::AlignCenter);
        view_ur = new QPushButton(tabView);
        view_ur->setObjectName(QString::fromUtf8("view_ur"));
        view_ur->setGeometry(QRect(310, 240, 24, 24));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/arrow_up_right_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_ur->setIcon(icon1);
        view_ur->setIconSize(QSize(24, 24));
        view_dr = new QPushButton(tabView);
        view_dr->setObjectName(QString::fromUtf8("view_dr"));
        view_dr->setGeometry(QRect(308, 300, 24, 24));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/arrow_down_right_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_dr->setIcon(icon2);
        view_dr->setIconSize(QSize(24, 24));
        ZoomEntry = new QLineEdit(tabView);
        ZoomEntry->setObjectName(QString::fromUtf8("ZoomEntry"));
        ZoomEntry->setGeometry(QRect(250, 200, 61, 25));
        ZoomEntry->setFont(font1);
        ZoomEntry->setAlignment(Qt::AlignCenter);
        pointerView = new QGraphicsView(tabView);
        pointerView->setObjectName(QString::fromUtf8("pointerView"));
        pointerView->setGeometry(QRect(390, 10, 250, 250));
        pointerView->setFrameShape(QFrame::NoFrame);
        pointerView->setFrameShadow(QFrame::Plain);
        pointerView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        pointerView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        QBrush brush1(QColor(0, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        pointerView->setBackgroundBrush(brush1);
        pointerView->setCacheMode(QGraphicsView::CacheBackground);
        pointerView->setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
        pointerView->setOptimizationFlags(QGraphicsView::DontAdjustForAntialiasing);
        view_center = new QPushButton(tabView);
        view_center->setObjectName(QString::fromUtf8("view_center"));
        view_center->setGeometry(QRect(280, 270, 24, 24));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/square_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_center->setIcon(icon3);
        view_center->setIconSize(QSize(24, 24));
        TextPixelValLabel = new QLabel(tabView);
        TextPixelValLabel->setObjectName(QString::fromUtf8("TextPixelValLabel"));
        TextPixelValLabel->setGeometry(QRect(486, 268, 51, 20));
        TextPixelValLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        heightEntry = new QLineEdit(tabView);
        heightEntry->setObjectName(QString::fromUtf8("heightEntry"));
        heightEntry->setGeometry(QRect(150, 300, 81, 25));
        heightEntry->setFont(font1);
        heightEntry->setAlignment(Qt::AlignCenter);
        Zoom8 = new QPushButton(tabView);
        Zoom8->setObjectName(QString::fromUtf8("Zoom8"));
        Zoom8->setGeometry(QRect(250, 70, 61, 24));
        Zoom8->setFont(font1);
        view_right = new QPushButton(tabView);
        view_right->setObjectName(QString::fromUtf8("view_right"));
        view_right->setGeometry(QRect(310, 270, 24, 24));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/icons/arrow_right_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_right->setIcon(icon4);
        view_right->setIconSize(QSize(24, 24));
        view_right->setCheckable(false);
        view_right->setFlat(false);
        view_down = new QPushButton(tabView);
        view_down->setObjectName(QString::fromUtf8("view_down"));
        view_down->setGeometry(QRect(280, 300, 24, 24));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/icons/arrow_down_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_down->setIcon(icon5);
        view_down->setIconSize(QSize(24, 24));
        TextCoordY = new QLabel(tabView);
        TextCoordY->setObjectName(QString::fromUtf8("TextCoordY"));
        TextCoordY->setGeometry(QRect(420, 292, 80, 20));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Button, brush);
        palette2.setBrush(QPalette::Active, QPalette::Base, brush);
        palette2.setBrush(QPalette::Active, QPalette::Window, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Window, brush);
        TextCoordY->setPalette(palette2);
        TextCoordY->setFont(font1);
        TextCoordY->setFrameShape(QFrame::Box);
        TextCoordY->setAlignment(Qt::AlignCenter);
        TextCoordY->setTextInteractionFlags(Qt::NoTextInteraction);
        Zoom2 = new QPushButton(tabView);
        Zoom2->setObjectName(QString::fromUtf8("Zoom2"));
        Zoom2->setGeometry(QRect(250, 140, 61, 24));
        Zoom2->setFont(font1);
        view_ul = new QPushButton(tabView);
        view_ul->setObjectName(QString::fromUtf8("view_ul"));
        view_ul->setGeometry(QRect(249, 240, 24, 24));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/icons/arrow_up_left_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_ul->setIcon(icon6);
        view_ul->setIconSize(QSize(24, 24));
        ZoomSlider = new QSlider(tabView);
        ZoomSlider->setObjectName(QString::fromUtf8("ZoomSlider"));
        ZoomSlider->setGeometry(QRect(320, 10, 23, 221));
        ZoomSlider->setFont(font1);
        ZoomSlider->setMaximum(280);
        ZoomSlider->setPageStep(1);
        ZoomSlider->setOrientation(Qt::Vertical);
        ZoomSlider->setTickPosition(QSlider::NoTicks);
        ZoomSlider->setTickInterval(40);
        label_9 = new QLabel(tabView);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(130, 270, 21, 25));
        label_9->setFont(font);
        label_9->setAlignment(Qt::AlignCenter);
        TextCoordXLabel = new QLabel(tabView);
        TextCoordXLabel->setObjectName(QString::fromUtf8("TextCoordXLabel"));
        TextCoordXLabel->setGeometry(QRect(380, 271, 31, 20));
        TextCoordXLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        Zoom16 = new QPushButton(tabView);
        Zoom16->setObjectName(QString::fromUtf8("Zoom16"));
        Zoom16->setGeometry(QRect(250, 40, 61, 24));
        Zoom16->setFont(font1);
        TextCoordYLabel = new QLabel(tabView);
        TextCoordYLabel->setObjectName(QString::fromUtf8("TextCoordYLabel"));
        TextCoordYLabel->setGeometry(QRect(380, 295, 31, 20));
        TextCoordYLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        view_dl = new QPushButton(tabView);
        view_dl->setObjectName(QString::fromUtf8("view_dl"));
        view_dl->setGeometry(QRect(250, 300, 24, 24));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/icons/arrow_down_left_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_dl->setIcon(icon7);
        view_dl->setIconSize(QSize(24, 24));
        xcenEntry = new QLineEdit(tabView);
        xcenEntry->setObjectName(QString::fromUtf8("xcenEntry"));
        xcenEntry->setGeometry(QRect(50, 270, 81, 25));
        xcenEntry->setFont(font1);
        xcenEntry->setAlignment(Qt::AlignCenter);
        Zoom1 = new QPushButton(tabView);
        Zoom1->setObjectName(QString::fromUtf8("Zoom1"));
        Zoom1->setGeometry(QRect(250, 170, 61, 24));
        Zoom1->setFont(font1);
        view_up = new QPushButton(tabView);
        view_up->setObjectName(QString::fromUtf8("view_up"));
        view_up->setGeometry(QRect(280, 240, 24, 24));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/icons/arrow_up_128.png"), QSize(), QIcon::Normal, QIcon::Off);
        view_up->setIcon(icon8);
        view_up->setIconSize(QSize(24, 24));
        viewView = new QGraphicsView(tabView);
        viewView->setObjectName(QString::fromUtf8("viewView"));
        viewView->setGeometry(QRect(10, 10, 231, 231));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(viewView->sizePolicy().hasHeightForWidth());
        viewView->setSizePolicy(sizePolicy);
        viewView->setAcceptDrops(false);
        viewView->setFrameShape(QFrame::NoFrame);
        viewView->setFrameShadow(QFrame::Plain);
        viewView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        viewView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        viewView->setBackgroundBrush(brush1);
        viewView->setOptimizationFlags(QGraphicsView::DontAdjustForAntialiasing);
        pointerSetLocButton = new QPushButton(tabView);
        pointerSetLocButton->setObjectName(QString::fromUtf8("pointerSetLocButton"));
        pointerSetLocButton->setGeometry(QRect(510, 290, 125, 26));
        overZoom4 = new QPushButton(tabView);
        overZoom4->setObjectName(QString::fromUtf8("overZoom4"));
        overZoom4->setGeometry(QRect(650, 90, 61, 24));
        overZoom4->setFont(font1);
        overZoom2 = new QPushButton(tabView);
        overZoom2->setObjectName(QString::fromUtf8("overZoom2"));
        overZoom2->setGeometry(QRect(650, 120, 61, 24));
        overZoom2->setFont(font1);
        overZoom1 = new QPushButton(tabView);
        overZoom1->setObjectName(QString::fromUtf8("overZoom1"));
        overZoom1->setGeometry(QRect(650, 150, 61, 24));
        overZoom1->setFont(font1);
        label_5 = new QLabel(tabView);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(650, 60, 61, 20));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignCenter);
        tabWidget->addTab(tabView, QString());
        tabColor = new QWidget();
        tabColor->setObjectName(QString::fromUtf8("tabColor"));
        maxdatLabel = new QLabel(tabColor);
        maxdatLabel->setObjectName(QString::fromUtf8("maxdatLabel"));
        maxdatLabel->setGeometry(QRect(5, 125, 71, 16));
        maxdatLabel->setFont(font);
        maxdatLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        mindatSlider = new QSlider(tabColor);
        mindatSlider->setObjectName(QString::fromUtf8("mindatSlider"));
        mindatSlider->setGeometry(QRect(80, 90, 160, 23));
        mindatSlider->setMouseTracking(false);
        mindatSlider->setMaximum(10000);
        mindatSlider->setOrientation(Qt::Horizontal);
        mindatEntry = new QLineEdit(tabColor);
        mindatEntry->setObjectName(QString::fromUtf8("mindatEntry"));
        mindatEntry->setGeometry(QRect(240, 90, 61, 25));
        mindatEntry->setFont(font1);
        mindatEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        mindatLabel = new QLabel(tabColor);
        mindatLabel->setObjectName(QString::fromUtf8("mindatLabel"));
        mindatLabel->setGeometry(QRect(5, 94, 71, 16));
        mindatLabel->setFont(font);
        mindatLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        maxdatSlider = new QSlider(tabColor);
        maxdatSlider->setObjectName(QString::fromUtf8("maxdatSlider"));
        maxdatSlider->setGeometry(QRect(80, 121, 160, 23));
        maxdatSlider->setMaximum(10000);
        maxdatSlider->setOrientation(Qt::Horizontal);
        maxdatEntry = new QLineEdit(tabColor);
        maxdatEntry->setObjectName(QString::fromUtf8("maxdatEntry"));
        maxdatEntry->setGeometry(QRect(240, 120, 61, 25));
        maxdatEntry->setFont(font1);
        maxdatEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        biasSlider = new QSlider(tabColor);
        biasSlider->setObjectName(QString::fromUtf8("biasSlider"));
        biasSlider->setGeometry(QRect(80, 152, 160, 23));
        biasSlider->setMaximum(10000);
        biasSlider->setOrientation(Qt::Horizontal);
        biasEntry = new QLineEdit(tabColor);
        biasEntry->setObjectName(QString::fromUtf8("biasEntry"));
        biasEntry->setGeometry(QRect(240, 150, 61, 25));
        biasEntry->setFont(font1);
        biasEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        biasLabel = new QLabel(tabColor);
        biasLabel->setObjectName(QString::fromUtf8("biasLabel"));
        biasLabel->setGeometry(QRect(5, 155, 71, 16));
        biasLabel->setFont(font);
        biasLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        contrastSlider = new QSlider(tabColor);
        contrastSlider->setObjectName(QString::fromUtf8("contrastSlider"));
        contrastSlider->setGeometry(QRect(80, 182, 160, 23));
        contrastSlider->setMaximum(10000);
        contrastSlider->setOrientation(Qt::Horizontal);
        contrastEntry = new QLineEdit(tabColor);
        contrastEntry->setObjectName(QString::fromUtf8("contrastEntry"));
        contrastEntry->setGeometry(QRect(240, 180, 61, 25));
        contrastEntry->setFont(font1);
        contrastEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        constrastLabel = new QLabel(tabColor);
        constrastLabel->setObjectName(QString::fromUtf8("constrastLabel"));
        constrastLabel->setGeometry(QRect(5, 182, 71, 20));
        constrastLabel->setFont(font);
        constrastLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        scaleModeCombo = new QComboBox(tabColor);
        scaleModeCombo->setObjectName(QString::fromUtf8("scaleModeCombo"));
        scaleModeCombo->setGeometry(QRect(0, 30, 125, 31));
        scaleModeCombo->setFont(font1);
        scaleTypeCombo = new QComboBox(tabColor);
        scaleTypeCombo->setObjectName(QString::fromUtf8("scaleTypeCombo"));
        scaleTypeCombo->setGeometry(QRect(130, 30, 120, 31));
        scaleTypeCombo->setFont(font1);
        colorbarCombo = new QComboBox(tabColor);
        colorbarCombo->setObjectName(QString::fromUtf8("colorbarCombo"));
        colorbarCombo->setGeometry(QRect(260, 30, 110, 31));
        colorbarCombo->setFont(font1);
        scalemodeLabel = new QLabel(tabColor);
        scalemodeLabel->setObjectName(QString::fromUtf8("scalemodeLabel"));
        scalemodeLabel->setGeometry(QRect(10, 10, 111, 16));
        scalemodeLabel->setFont(font);
        scalemodeLabel->setAlignment(Qt::AlignCenter);
        scaletypeLabel = new QLabel(tabColor);
        scaletypeLabel->setObjectName(QString::fromUtf8("scaletypeLabel"));
        scaletypeLabel->setGeometry(QRect(130, 10, 121, 16));
        scaletypeLabel->setFont(font);
        scaletypeLabel->setAlignment(Qt::AlignCenter);
        colorbarlabel = new QLabel(tabColor);
        colorbarlabel->setObjectName(QString::fromUtf8("colorbarlabel"));
        colorbarlabel->setGeometry(QRect(270, 10, 91, 16));
        colorbarlabel->setFont(font);
        colorbarlabel->setAlignment(Qt::AlignCenter);
        mindatRelEntry = new QLineEdit(tabColor);
        mindatRelEntry->setObjectName(QString::fromUtf8("mindatRelEntry"));
        mindatRelEntry->setGeometry(QRect(310, 90, 61, 25));
        mindatRelEntry->setFont(font1);
        mindatRelEntry->setInputMask(QString::fromUtf8(""));
        mindatRelEntry->setText(QString::fromUtf8(""));
        mindatRelEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        maxdatRelEntry = new QLineEdit(tabColor);
        maxdatRelEntry->setObjectName(QString::fromUtf8("maxdatRelEntry"));
        maxdatRelEntry->setGeometry(QRect(310, 120, 61, 25));
        maxdatRelEntry->setFont(font1);
        maxdatRelEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        biasRelEntry = new QLineEdit(tabColor);
        biasRelEntry->setObjectName(QString::fromUtf8("biasRelEntry"));
        biasRelEntry->setGeometry(QRect(310, 150, 61, 25));
        biasRelEntry->setFont(font1);
        biasRelEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        contrastRelEntry = new QLineEdit(tabColor);
        contrastRelEntry->setObjectName(QString::fromUtf8("contrastRelEntry"));
        contrastRelEntry->setGeometry(QRect(310, 180, 61, 25));
        contrastRelEntry->setFont(font1);
        contrastRelEntry->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        absfixedButton = new QPushButton(tabColor);
        absfixedButton->setObjectName(QString::fromUtf8("absfixedButton"));
        absfixedButton->setGeometry(QRect(240, 60, 61, 31));
        relfixedButton = new QPushButton(tabColor);
        relfixedButton->setObjectName(QString::fromUtf8("relfixedButton"));
        relfixedButton->setGeometry(QRect(310, 60, 61, 31));
        tabWidget->addTab(tabColor, QString());
        tabSetup = new QWidget();
        tabSetup->setObjectName(QString::fromUtf8("tabSetup"));
        ViewViewModecheckBox = new QCheckBox(tabSetup);
        ViewViewModecheckBox->setObjectName(QString::fromUtf8("ViewViewModecheckBox"));
        ViewViewModecheckBox->setGeometry(QRect(20, 60, 231, 21));
        ViewViewModecheckBox->setChecked(false);
        pointerViewModecomboBox = new QComboBox(tabSetup);
        pointerViewModecomboBox->setObjectName(QString::fromUtf8("pointerViewModecomboBox"));
        pointerViewModecomboBox->setGeometry(QRect(110, 20, 171, 31));
        label = new QLabel(tabSetup);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 30, 101, 16));
        imtimerspinBox = new QSpinBox(tabSetup);
        imtimerspinBox->setObjectName(QString::fromUtf8("imtimerspinBox"));
        imtimerspinBox->setGeometry(QRect(490, 10, 121, 23));
        imtimerspinBox->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        imtimerspinBox->setMinimum(1);
        imtimerspinBox->setMaximum(3600000);
        imtimerspinBox->setSingleStep(10);
        imtimerspinBox->setValue(20);
        label_2 = new QLabel(tabSetup);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(340, 12, 141, 20));
        statsBoxButton = new QPushButton(tabSetup);
        statsBoxButton->setObjectName(QString::fromUtf8("statsBoxButton"));
        statsBoxButton->setGeometry(QRect(30, 100, 191, 24));
        toolTipCoordsButton = new QPushButton(tabSetup);
        toolTipCoordsButton->setObjectName(QString::fromUtf8("toolTipCoordsButton"));
        toolTipCoordsButton->setGeometry(QRect(30, 130, 191, 24));
        staticCoordsButton = new QPushButton(tabSetup);
        staticCoordsButton->setObjectName(QString::fromUtf8("staticCoordsButton"));
        staticCoordsButton->setGeometry(QRect(30, 160, 191, 24));
        verticalLayoutWidget = new QWidget(tabSetup);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(370, 170, 321, 140));
        vLayoutTargetCross = new QVBoxLayout(verticalLayoutWidget);
        vLayoutTargetCross->setObjectName(QString::fromUtf8("vLayoutTargetCross"));
        vLayoutTargetCross->setContentsMargins(0, 0, 0, 0);
        hlTargetCross = new QHBoxLayout();
        hlTargetCross->setObjectName(QString::fromUtf8("hlTargetCross"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hlTargetCross->addItem(horizontalSpacer);

        labelTargetCross = new QLabel(verticalLayoutWidget);
        labelTargetCross->setObjectName(QString::fromUtf8("labelTargetCross"));
        labelTargetCross->setAlignment(Qt::AlignCenter);

        hlTargetCross->addWidget(labelTargetCross);

        buttonTargetCross = new QPushButton(verticalLayoutWidget);
        buttonTargetCross->setObjectName(QString::fromUtf8("buttonTargetCross"));

        hlTargetCross->addWidget(buttonTargetCross);

        hlTargetCross->setStretch(0, 1);
        hlTargetCross->setStretch(1, 2);
        hlTargetCross->setStretch(2, 1);

        vLayoutTargetCross->addLayout(hlTargetCross);

        gLayoutTargetCross = new QGridLayout();
        gLayoutTargetCross->setObjectName(QString::fromUtf8("gLayoutTargetCross"));
        lineEditTargetFractionY = new QLineEdit(verticalLayoutWidget);
        lineEditTargetFractionY->setObjectName(QString::fromUtf8("lineEditTargetFractionY"));

        gLayoutTargetCross->addWidget(lineEditTargetFractionY, 2, 2, 1, 1);

        lineEditTargetPixelX = new QLineEdit(verticalLayoutWidget);
        lineEditTargetPixelX->setObjectName(QString::fromUtf8("lineEditTargetPixelX"));

        gLayoutTargetCross->addWidget(lineEditTargetPixelX, 1, 1, 1, 1);

        labelPixel = new QLabel(verticalLayoutWidget);
        labelPixel->setObjectName(QString::fromUtf8("labelPixel"));

        gLayoutTargetCross->addWidget(labelPixel, 1, 0, 1, 1);

        labelFraction = new QLabel(verticalLayoutWidget);
        labelFraction->setObjectName(QString::fromUtf8("labelFraction"));

        gLayoutTargetCross->addWidget(labelFraction, 2, 0, 1, 1);

        lineEditTargetFractionX = new QLineEdit(verticalLayoutWidget);
        lineEditTargetFractionX->setObjectName(QString::fromUtf8("lineEditTargetFractionX"));

        gLayoutTargetCross->addWidget(lineEditTargetFractionX, 2, 1, 1, 1);

        labelTargetY = new QLabel(verticalLayoutWidget);
        labelTargetY->setObjectName(QString::fromUtf8("labelTargetY"));
        labelTargetY->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gLayoutTargetCross->addWidget(labelTargetY, 0, 2, 1, 1);

        labelTargetX = new QLabel(verticalLayoutWidget);
        labelTargetX->setObjectName(QString::fromUtf8("labelTargetX"));
        labelTargetX->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        gLayoutTargetCross->addWidget(labelTargetX, 0, 1, 1, 1);

        lineEditTargetPixelY = new QLineEdit(verticalLayoutWidget);
        lineEditTargetPixelY->setObjectName(QString::fromUtf8("lineEditTargetPixelY"));

        gLayoutTargetCross->addWidget(lineEditTargetPixelY, 1, 2, 1, 1);


        vLayoutTargetCross->addLayout(gLayoutTargetCross);

        tabWidget->addTab(tabSetup, QString());
        QWidget::setTabOrder(xcenEntry, ycenEntry);
        QWidget::setTabOrder(ycenEntry, widthEntry);
        QWidget::setTabOrder(widthEntry, heightEntry);
        QWidget::setTabOrder(heightEntry, ZoomEntry);
        QWidget::setTabOrder(ZoomEntry, mindatEntry);
        QWidget::setTabOrder(mindatEntry, maxdatEntry);
        QWidget::setTabOrder(maxdatEntry, biasEntry);
        QWidget::setTabOrder(biasEntry, contrastEntry);
        QWidget::setTabOrder(contrastEntry, mindatRelEntry);
        QWidget::setTabOrder(mindatRelEntry, maxdatRelEntry);
        QWidget::setTabOrder(maxdatRelEntry, biasRelEntry);
        QWidget::setTabOrder(biasRelEntry, contrastRelEntry);
        QWidget::setTabOrder(contrastRelEntry, Zoom2);
        QWidget::setTabOrder(Zoom2, view_ul);
        QWidget::setTabOrder(view_ul, view_dr);
        QWidget::setTabOrder(view_dr, Zoom16);
        QWidget::setTabOrder(Zoom16, view_dl);
        QWidget::setTabOrder(view_dl, view_left);
        QWidget::setTabOrder(view_left, tabWidget);
        QWidget::setTabOrder(tabWidget, viewView);
        QWidget::setTabOrder(viewView, view_up);
        QWidget::setTabOrder(view_up, Zoom4);
        QWidget::setTabOrder(Zoom4, pointerSetLocButton);
        QWidget::setTabOrder(pointerSetLocButton, mindatSlider);
        QWidget::setTabOrder(mindatSlider, Zoom1);
        QWidget::setTabOrder(Zoom1, maxdatSlider);
        QWidget::setTabOrder(maxdatSlider, pointerView);
        QWidget::setTabOrder(pointerView, biasSlider);
        QWidget::setTabOrder(biasSlider, ZoomSlider);
        QWidget::setTabOrder(ZoomSlider, contrastSlider);
        QWidget::setTabOrder(contrastSlider, view_center);
        QWidget::setTabOrder(view_center, scaleModeCombo);
        QWidget::setTabOrder(scaleModeCombo, scaleTypeCombo);
        QWidget::setTabOrder(scaleTypeCombo, colorbarCombo);
        QWidget::setTabOrder(colorbarCombo, view_ur);
        QWidget::setTabOrder(view_ur, Zoom8);
        QWidget::setTabOrder(Zoom8, view_right);
        QWidget::setTabOrder(view_right, view_down);
        QWidget::setTabOrder(view_down, absfixedButton);
        QWidget::setTabOrder(absfixedButton, relfixedButton);
        QWidget::setTabOrder(relfixedButton, ViewViewModecheckBox);
        QWidget::setTabOrder(ViewViewModecheckBox, pointerViewModecomboBox);
        QWidget::setTabOrder(pointerViewModecomboBox, imtimerspinBox);

        retranslateUi(imviewerControlPanel);

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(imviewerControlPanel);
    } // setupUi

    void retranslateUi(QWidget *imviewerControlPanel)
    {
        imviewerControlPanel->setWindowTitle(QCoreApplication::translate("imviewerControlPanel", "imviewer control panel", nullptr));
        TextPixelVal->setText(QString());
        label_10->setText(QCoreApplication::translate("imviewerControlPanel", "Y cen", nullptr));
        Zoom4->setText(QCoreApplication::translate("imviewerControlPanel", "4", nullptr));
        label_4->setText(QCoreApplication::translate("imviewerControlPanel", "Zoom", nullptr));
        ycenEntry->setInputMask(QString());
        ycenEntry->setText(QString());
        TextCoordX->setText(QString());
        label_12->setText(QCoreApplication::translate("imviewerControlPanel", "H", nullptr));
        view_left->setText(QString());
        widthEntry->setInputMask(QString());
        widthEntry->setText(QString());
        label_11->setText(QCoreApplication::translate("imviewerControlPanel", "X cen", nullptr));
        view_ur->setText(QString());
        view_dr->setText(QString());
        ZoomEntry->setInputMask(QString());
        ZoomEntry->setText(QCoreApplication::translate("imviewerControlPanel", "1.00", nullptr));
        view_center->setText(QString());
        TextPixelValLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Val.", nullptr));
        heightEntry->setInputMask(QString());
        heightEntry->setText(QString());
        Zoom8->setText(QCoreApplication::translate("imviewerControlPanel", "8", nullptr));
        view_right->setText(QString());
        view_down->setText(QString());
        TextCoordY->setText(QString());
        Zoom2->setText(QCoreApplication::translate("imviewerControlPanel", "2", nullptr));
        view_ul->setText(QString());
        label_9->setText(QCoreApplication::translate("imviewerControlPanel", "W", nullptr));
        TextCoordXLabel->setText(QCoreApplication::translate("imviewerControlPanel", "X", nullptr));
        Zoom16->setText(QCoreApplication::translate("imviewerControlPanel", "16", nullptr));
        TextCoordYLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Y", nullptr));
        view_dl->setText(QString());
        xcenEntry->setInputMask(QString());
        xcenEntry->setText(QString());
        Zoom1->setText(QCoreApplication::translate("imviewerControlPanel", "1", nullptr));
        view_up->setText(QString());
        pointerSetLocButton->setText(QCoreApplication::translate("imviewerControlPanel", "Set Location", nullptr));
        overZoom4->setText(QCoreApplication::translate("imviewerControlPanel", "4", nullptr));
        overZoom2->setText(QCoreApplication::translate("imviewerControlPanel", "2", nullptr));
        overZoom1->setText(QCoreApplication::translate("imviewerControlPanel", "1", nullptr));
        label_5->setText(QCoreApplication::translate("imviewerControlPanel", "+Zoom", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tabView), QCoreApplication::translate("imviewerControlPanel", "View", nullptr));
        maxdatLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Max:", nullptr));
        mindatEntry->setInputMask(QString());
        mindatEntry->setText(QString());
        mindatLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Min:", nullptr));
        maxdatEntry->setInputMask(QString());
        maxdatEntry->setText(QString());
        biasEntry->setInputMask(QString());
        biasEntry->setText(QString());
        biasLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Bias:", nullptr));
        contrastEntry->setInputMask(QString());
        contrastEntry->setText(QString());
        constrastLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Contrast:", nullptr));
        scalemodeLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Mode", nullptr));
        scaletypeLabel->setText(QCoreApplication::translate("imviewerControlPanel", "Type", nullptr));
        colorbarlabel->setText(QCoreApplication::translate("imviewerControlPanel", "Color Bar", nullptr));
        maxdatRelEntry->setInputMask(QString());
        maxdatRelEntry->setText(QString());
        biasRelEntry->setInputMask(QString());
        biasRelEntry->setText(QString());
        contrastRelEntry->setInputMask(QString());
        contrastRelEntry->setText(QString());
        absfixedButton->setText(QCoreApplication::translate("imviewerControlPanel", "Abs.", nullptr));
        relfixedButton->setText(QCoreApplication::translate("imviewerControlPanel", "Rel.", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tabColor), QCoreApplication::translate("imviewerControlPanel", "Color", nullptr));
        ViewViewModecheckBox->setText(QCoreApplication::translate("imviewerControlPanel", "Show image in zoom view", nullptr));
        label->setText(QCoreApplication::translate("imviewerControlPanel", "Pointer View", nullptr));
        imtimerspinBox->setSuffix(QCoreApplication::translate("imviewerControlPanel", "ms", nullptr));
        label_2->setText(QCoreApplication::translate("imviewerControlPanel", "Image get timeout", nullptr));
        statsBoxButton->setText(QCoreApplication::translate("imviewerControlPanel", "Show Stats Box", nullptr));
        toolTipCoordsButton->setText(QCoreApplication::translate("imviewerControlPanel", "Show Pointer Coords", nullptr));
        staticCoordsButton->setText(QCoreApplication::translate("imviewerControlPanel", "Show Static Coords", nullptr));
        labelTargetCross->setText(QCoreApplication::translate("imviewerControlPanel", "Target Cross", nullptr));
        buttonTargetCross->setText(QCoreApplication::translate("imviewerControlPanel", "show", nullptr));
        labelPixel->setText(QCoreApplication::translate("imviewerControlPanel", "Pixel", nullptr));
        labelFraction->setText(QCoreApplication::translate("imviewerControlPanel", "Fraction", nullptr));
        labelTargetY->setText(QCoreApplication::translate("imviewerControlPanel", "Y", nullptr));
        labelTargetX->setText(QCoreApplication::translate("imviewerControlPanel", "X", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tabSetup), QCoreApplication::translate("imviewerControlPanel", "Setup", nullptr));
    } // retranslateUi

};

namespace Ui {
    class imviewerControlPanel: public Ui_imviewerControlPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMVIEWERCONTROLPANEL_H
