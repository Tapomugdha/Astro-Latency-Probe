/********************************************************************************
** Form generated from reading UI file 'imviewerStats.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMVIEWERSTATS_H
#define UI_IMVIEWERSTATS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_statsform
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelMax;
    QLabel *dataMax;
    QHBoxLayout *horizontalLayout;
    QLabel *labelMin;
    QLabel *dataMin;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelMean;
    QLabel *dataMean;
    QHBoxLayout *horizontalLayout_4;
    QLabel *labelMedian;
    QLabel *dataMedian;

    void setupUi(QDialog *statsform)
    {
        if (statsform->objectName().isEmpty())
            statsform->setObjectName(QString::fromUtf8("statsform"));
        statsform->resize(238, 149);
        gridLayout = new QGridLayout(statsform);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        labelMax = new QLabel(statsform);
        labelMax->setObjectName(QString::fromUtf8("labelMax"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(labelMax->sizePolicy().hasHeightForWidth());
        labelMax->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        labelMax->setFont(font);

        horizontalLayout_2->addWidget(labelMax);

        dataMax = new QLabel(statsform);
        dataMax->setObjectName(QString::fromUtf8("dataMax"));
        sizePolicy.setHeightForWidth(dataMax->sizePolicy().hasHeightForWidth());
        dataMax->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setWeight(50);
        dataMax->setFont(font1);
        dataMax->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(dataMax);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 3);

        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        labelMin = new QLabel(statsform);
        labelMin->setObjectName(QString::fromUtf8("labelMin"));
        sizePolicy.setHeightForWidth(labelMin->sizePolicy().hasHeightForWidth());
        labelMin->setSizePolicy(sizePolicy);
        labelMin->setFont(font);

        horizontalLayout->addWidget(labelMin);

        dataMin = new QLabel(statsform);
        dataMin->setObjectName(QString::fromUtf8("dataMin"));
        sizePolicy.setHeightForWidth(dataMin->sizePolicy().hasHeightForWidth());
        dataMin->setSizePolicy(sizePolicy);
        dataMin->setFont(font1);
        dataMin->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(dataMin);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 3);

        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        labelMean = new QLabel(statsform);
        labelMean->setObjectName(QString::fromUtf8("labelMean"));
        sizePolicy.setHeightForWidth(labelMean->sizePolicy().hasHeightForWidth());
        labelMean->setSizePolicy(sizePolicy);
        labelMean->setFont(font);

        horizontalLayout_3->addWidget(labelMean);

        dataMean = new QLabel(statsform);
        dataMean->setObjectName(QString::fromUtf8("dataMean"));
        sizePolicy.setHeightForWidth(dataMean->sizePolicy().hasHeightForWidth());
        dataMean->setSizePolicy(sizePolicy);
        dataMean->setFont(font1);
        dataMean->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(dataMean);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 3);

        gridLayout->addLayout(horizontalLayout_3, 2, 0, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        labelMedian = new QLabel(statsform);
        labelMedian->setObjectName(QString::fromUtf8("labelMedian"));
        sizePolicy.setHeightForWidth(labelMedian->sizePolicy().hasHeightForWidth());
        labelMedian->setSizePolicy(sizePolicy);
        labelMedian->setFont(font);

        horizontalLayout_4->addWidget(labelMedian);

        dataMedian = new QLabel(statsform);
        dataMedian->setObjectName(QString::fromUtf8("dataMedian"));
        sizePolicy.setHeightForWidth(dataMedian->sizePolicy().hasHeightForWidth());
        dataMedian->setSizePolicy(sizePolicy);
        dataMedian->setFont(font1);
        dataMedian->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(dataMedian);

        horizontalLayout_4->setStretch(0, 1);
        horizontalLayout_4->setStretch(1, 3);

        gridLayout->addLayout(horizontalLayout_4, 3, 0, 1, 1);


        retranslateUi(statsform);

        QMetaObject::connectSlotsByName(statsform);
    } // setupUi

    void retranslateUi(QDialog *statsform)
    {
        statsform->setWindowTitle(QCoreApplication::translate("statsform", "Region Stats", nullptr));
        labelMax->setText(QCoreApplication::translate("statsform", "Max:", nullptr));
        dataMax->setText(QCoreApplication::translate("statsform", "16383.00", nullptr));
        labelMin->setText(QCoreApplication::translate("statsform", "Min:", nullptr));
        dataMin->setText(QCoreApplication::translate("statsform", "16383.00", nullptr));
        labelMean->setText(QCoreApplication::translate("statsform", "Mean:", nullptr));
        dataMean->setText(QCoreApplication::translate("statsform", "16383.00", nullptr));
        labelMedian->setText(QCoreApplication::translate("statsform", "Median:", nullptr));
        dataMedian->setText(QCoreApplication::translate("statsform", "16383.00", nullptr));
    } // retranslateUi

};

namespace Ui {
    class statsform: public Ui_statsform {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMVIEWERSTATS_H
