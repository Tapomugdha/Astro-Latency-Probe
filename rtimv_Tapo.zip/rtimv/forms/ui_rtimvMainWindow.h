/********************************************************************************
** Form generated from reading UI file 'rtimvMainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RTIMVMAINWINDOW_H
#define UI_RTIMVMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "src/rtimvGraphicsView.hpp"

QT_BEGIN_NAMESPACE

class Ui_rtimvMainWindow
{
public:
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_top;
    rtimvGraphicsView *graphicsView;

    void setupUi(QWidget *rtimvMainWindow)
    {
        if (rtimvMainWindow->objectName().isEmpty())
            rtimvMainWindow->setObjectName(QString::fromUtf8("rtimvMainWindow"));
        rtimvMainWindow->resize(587, 655);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(rtimvMainWindow->sizePolicy().hasHeightForWidth());
        rtimvMainWindow->setSizePolicy(sizePolicy);
        rtimvMainWindow->setMouseTracking(true);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/scamper_cutout_sq_64.png"), QSize(), QIcon::Normal, QIcon::Off);
        rtimvMainWindow->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(rtimvMainWindow);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout_top = new QGridLayout();
        gridLayout_top->setObjectName(QString::fromUtf8("gridLayout_top"));
        graphicsView = new rtimvGraphicsView(rtimvMainWindow);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        sizePolicy.setHeightForWidth(graphicsView->sizePolicy().hasHeightForWidth());
        graphicsView->setSizePolicy(sizePolicy);
        graphicsView->setMinimumSize(QSize(10, 10));
        graphicsView->setMaximumSize(QSize(10000000, 10000000));
        graphicsView->setSizeIncrement(QSize(0, 0));
        graphicsView->setBaseSize(QSize(0, 0));
        graphicsView->setMouseTracking(true);
        graphicsView->setAcceptDrops(false);
        graphicsView->setFrameShape(QFrame::NoFrame);
        graphicsView->setFrameShadow(QFrame::Plain);
        graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        graphicsView->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        graphicsView->setInteractive(true);
        graphicsView->setSceneRect(QRectF(0, 0, 0, 0));
        graphicsView->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView->setResizeAnchor(QGraphicsView::AnchorUnderMouse);
        graphicsView->setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
        graphicsView->setRubberBandSelectionMode(Qt::IntersectsItemBoundingRect);
        graphicsView->setOptimizationFlags(QGraphicsView::DontAdjustForAntialiasing);

        gridLayout_top->addWidget(graphicsView, 0, 0, 2, 1);


        verticalLayout->addLayout(gridLayout_top);

        verticalLayout->setStretch(0, 20);

        retranslateUi(rtimvMainWindow);
        QObject::connect(graphicsView, SIGNAL(centerChanged()), rtimvMainWindow, SLOT(changeCenter()));
        QObject::connect(graphicsView, SIGNAL(mouseCoordsChanged()), rtimvMainWindow, SLOT(changeMouseCoords()));
        QObject::connect(graphicsView, SIGNAL(leftClicked(QPointF)), rtimvMainWindow, SLOT(viewLeftClicked(QPointF)));
        QObject::connect(graphicsView, SIGNAL(rightPressed(QPointF)), rtimvMainWindow, SLOT(viewRightPressed(QPointF)));
        QObject::connect(graphicsView, SIGNAL(leftPressed(QPointF)), rtimvMainWindow, SLOT(viewLeftPressed(QPointF)));
        QObject::connect(graphicsView, SIGNAL(rightClicked(QPointF)), rtimvMainWindow, SLOT(viewRightClicked(QPointF)));
        QObject::connect(graphicsView, SIGNAL(wheelMoved(int)), rtimvMainWindow, SLOT(onWheelMoved(int)));

        QMetaObject::connectSlotsByName(rtimvMainWindow);
    } // setupUi

    void retranslateUi(QWidget *rtimvMainWindow)
    {
        rtimvMainWindow->setWindowTitle(QCoreApplication::translate("rtimvMainWindow", "imviewer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class rtimvMainWindow: public Ui_rtimvMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RTIMVMAINWINDOW_H
